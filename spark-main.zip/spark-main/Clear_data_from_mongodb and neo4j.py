#!/usr/bin/env python
# coding: utf-8

# ## Connect to the mongodb and delete database

# In[1]:


import pymongo
from pymongo import MongoClient


# In[2]:


client = MongoClient("mongodb://127.0.0.1:27017")
db = client.MED_EX_CHAIN

gpo = db.GPO
product = db.PRODUCT
hospital = db.HOSPITAL
user_roles = db.USER_ROLES
distributor = db.DISTRIBUTOR
manufacturer = db.MANUFACTURER
correlation = db.CORRELATION_DATA


# In[3]:


gpo.drop()
product.drop()
hospital.drop()
user_roles.drop()
distributor.drop()
manufacturer.drop()
correlation.drop()


# ## connect to neo4j and delete nodes and relationship

# In[4]:


from py2neo import *

graph = Graph("bolt://localhost:7687", auth = ("neo4j", "shubham"))


# In[7]:


graph.delete_all()


# In[6]:


graph.run("match (n) detach delete (n)")


# In[ ]:




