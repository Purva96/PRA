# COMMANDS TO INSTALL ANACONDA ON UBUNTU 18.04:
1. cd /tmp
2. curl -O https://repo.anaconda.com/archive/Anaconda3-5.2.0-Linux-x86_64.sh (to download Anaconda - yesthe package manager)
3. sha256sum Anaconda3-5.2.0-Linux-x86_64.sh (to verify integrety of donwloaded Anaconda. The token is matched with and external Anaconda site for veracty verification)
4. bash Anaconda3-5.2.0-Linux-x86_64.sh (to start installation)
5. source ~/.bashrc (to activate anaconda installation)
6. conda info (verify installation)
7. conda update conda (to update anaconda)

8. Create Anaconda Virtual environment:
   conda create -n (medexchain) python=3.7 anaconda

# To install jupyter notebook and connect Anaconda Environemnt Kernel to Jupyter:
1. Activate your conda environment:- conda activate medexchain
2. conda install jupyter
3. conda install nb_conda
   (Note: For this step ensure python of your Anaconda is bely version 3.9.
    If not, run conda install python==3.7)
4. conda install ipykernel - # makes Jupiter envvironment interactive 
5. python -m ipykernel install --user --name (your conda environment name i.e medexchain)

conda activate medexchain

# COMMANDS TO SETUP PROJECT:
1. cd ~/STY/MedExChain/
   1.b  pip3 install -r requirements.txt         # Run requirements.txt
2. Install Java: 
        sudo add-apt-repository ppa:webupd8team/java
        sudo apt-get update
        sudo apt install openjdk-8-jdk  
3. Install MongoDB: 
        sudo apt update
        sudo apt install mongodb
        mongo
4. Install Neo4j:
        sudo apt update

        sudo wget -O - https://debian.neo4j.org/neotechnology.gpg.key | sudo apt-key add -

        sudo echo 'deb https://debian.neo4j.org/repo stable/' | sudo tee -a /etc/apt/sources.list.d/neo4j.list

        sudo apt-get update

        sudo apt install neo4j

        neo4j --version

        sudo nano /etc/neo4j/neo4j.conf     # this is where the ip address of the AWS instance is configured

        ps aux | grep "org.neo4j.server"
        
        sudo kill <JAVA-PROCESS-ID>

        sudo rm /var/lib/neo4j/data/databases/store_lock

        sudo neo4j start

        cat /var/log/neo4j/neo4j.log (TO CHECK IF NEO4J HAS STARTED PROPERLY)        




#### NEO4J COMMANDS
sudo neo4j start
cat /var/log/neo4j/neo4j.log

<!-- FOR CLIENT INSTANCE -->
In Browser: http://34.226.239.38:7474/
Username: neo4j
Password: medex123

<!-- FOR T3XLARGE INSTANCE -->
In Browser: http://35.174.19.21:7474/
Username: neo4j
Password: neo4j

# In AWS the ports mentioned above have to be enabled via IAM to access the
# database/browser other wise we would not be able to run this on the local machines browser

#### Database Truncate Commands - empty out the database 
>> mongo
        1. show dbs
        2. use MED_EX_CHAIN
                switched to db mydb
        3. db.dropDatabase()
                { "dropped" : "mydb", "ok" : 1 }
        4. show dbs

>> neo4j
        1. MATCH (n) DETACH DELETE n;
        2. sudo neo4j stop        
        3. sudo rm -rf /var/lib/neo4j/data/databases/graph.db



#### MONGO-REPAIR
sudo mongod --repair
sudo mongod &   (TO RUN MONGOD IN BACKGROUND)
mongo
