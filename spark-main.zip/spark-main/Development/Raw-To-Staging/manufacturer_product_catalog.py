import pymongo
from pymongo import MongoClient
import pprint
import pandas as pd
import json as json
import numpy as np
import findspark
from datetime import datetime
findspark.init('/home/ubuntu/Product_MDM-STY/spark-3.1.1-bin-hadoop2.7')
import pyspark
from pyspark import SparkContext
from pyspark.sql import SparkSession, SQLContext
from pyspark.sql.functions import *
spark = SparkSession.\
builder.\
appName("pyspark-notebook2").\
config("spark.executor.memory", "1g").\
config("spark.jars.packages", "org.mongodb.spark:mongo-spark-connector_2.12:3.0.0").\
getOrCreate()

client = MongoClient("mongodb://127.0.0.1:27017")

db=client.MED_EX_CHAIN
product=db.PRODUCT

file_name= input('Enter Manufacturer product catalog File Name: ')

manufacturer_catalog=spark.read.csv("../Data/"+file_name, header = True).dropna(how='all')

manufacturer_catalog= manufacturer_catalog.select(col('Item number'),col('Manufacturer_Catalog_Number'),
       col('Description'), col('Size'), col('Gauge'), col('Color'), col('BUOM'), col('UM'),
       col('Base Price'), col(' PRODUCT_TYPE_ID '), col(' NAME '), col(' SHORT_DESCRIPTION '),
       col(' PRODUCT_STATUS '), col(' IS_PACK '), col(' UNITS_IN_PACK '), col(' PRODUCT_CATEGORY '),
       col(' MFG_DATE '), col(' EXPIRY_DATE '), col(' PRODUCT_IMAGE '),col('Manufacturer'))

manufacturer_catalog=manufacturer_catalog.withColumnRenamed('Item number','PRODUCT_ID').\
                                          withColumnRenamed('Description','DESCRIPTION').\
                                          withColumnRenamed('Manufacturer','MANUFACTURER').\
                                          withColumnRenamed('Size','SIZE').\
                                          withColumnRenamed('Manufacturer_Catalog_Number','CATALOG_NUMBER').\
                                          withColumnRenamed('Gauge','VOLUME').\
                                          withColumnRenamed('Color','COLOR').\
                                          withColumnRenamed('BUOM','WEIGHT_UOM').\
                                          withColumnRenamed('UM','UOM').\
                                          withColumnRenamed('Base Price','BASE_PRICE').\
                                          withColumnRenamed(' PRODUCT_TYPE_ID ','PRODUCT_TYPE_ID').\
                                          withColumnRenamed(' NAME ','NAME').\
                                        withColumnRenamed(' SHORT_DESCRIPTION ','SHORT_DESCRIPTION').\
                                        withColumnRenamed(' PRODUCT_STATUS ','PRODUCT_STATUS').\
                                        withColumnRenamed(' IS_PACK ','IS_PACK').\
                                        withColumnRenamed(' UNITS_IN_PACK ','UNITS_IN_PACK').\
                                        withColumnRenamed(' PRODUCT_CATEGORY ','PRODUCT_CATEGORY').\
                                        withColumnRenamed(' MFG_DATE ','MFG_DATE').\
                                        withColumnRenamed(' EXPIRY_DATE ','EXPIRY_DATE').\
                                        withColumnRenamed(' PRODUCT_IMAGE ','PRODUCT_IMAGE')
                                        

product_data = spark.read.format("mongo").option("uri",
                                "mongodb://127.0.0.1:27017/MED_EX_CHAIN.PRODUCT").load()

product_data.createOrReplaceTempView('product_view')

for i in manufacturer_catalog.toJSON().collect():
    new_record = json.loads(i)
    product_id = new_record['PRODUCT_ID']
    query = "select * from product_view where PRODUCT_ID = '"+product_id+"' and\
                    VERSION = (select max(VERSION) from product_view \
                    where PRODUCT_ID = '"+product_id+"')"
    available_data= spark.sql(query)
    print(product_id, available_data.count())
    
    if available_data.count()==0: # no data available, insert with version 1.0
        insert_data = dict(new_record)
        insert_data['VERSION']=1.0
        insert_data['START_DATE'] = str(datetime.now())
        insert_data['END_DATE'] = str('9999-12-31')
        insert_data['LAST_UPDATE_DT'] = str(datetime.now())
        product.insert_one(insert_data)
        print('insert data with 1 version.')
    
 # insert data with new version.    
    elif (new_record['NAME'] != available_data.rdd.collect()[0]['NAME'])|\
          (new_record['DESCRIPTION'] != available_data.rdd.collect()[0]['DESCRIPTION'])|\
    (new_record['BASE_PRICE'] != available_data.rdd.collect()[0]['BASE_PRICE'])|\
    (new_record['CATALOG_NUMBER'] != available_data.rdd.collect()[0]['CATALOG_NUMBER'])|\
    (new_record['UNITS_IN_PACK'] != available_data.rdd.collect()[0]['UNITS_IN_PACK'])|\
    (new_record['SHORT_DESCRIPTION'] != available_data.rdd.collect()[0]['SHORT_DESCRIPTION']): # add conditions for all the columns which are eligible for the SCD.
        product.update_many({'PRODUCT_ID':product_id , 'VERSION': int(available_data.collect()[0].asDict()['VERSION'])},
                                         {"$set":{'LAST_UPDATE_DT':str(datetime.now()),
                                            'END_DATE':str(datetime.now())}})
        insert_data = dict(new_record)
        insert_data['START_DATE'] = str(datetime.now())
        insert_data['END_DATE'] = str('9999-12-31')
        insert_data['LAST_UPDATE_DT'] = str(datetime.now())
        insert_data['VERSION']=int(available_data.collect()[0].asDict()['VERSION']) + 1
        product.insert_one(insert_data)
        print('insert data with updated + 1 version.')
                
                
    else:
        update_data = dict(new_record)
        update_data['LAST_UPDATE_DT']= str(datetime.now())
        product.update_one({'PRODUCT_ID':product_id, 'VERSION': int(available_data.collect()[0].asDict()['VERSION'])},
                                         {"$set": update_data})
        print('update record with same latest version')  # update existing data with same version.
