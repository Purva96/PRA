
# coding: utf-8

# In[19]:


import pymongo
from pymongo import MongoClient
import pprint
import pandas as pd
import json
import numpy as np
client = MongoClient("mongodb://127.0.0.1:27017")


# In[20]:


db=client.MED_EX_CHAIN
product=db.PRODUCT

manufacturer_file = input('Enter manufacturer product catalog file name: ')
distributor_file = input('Enter distributor product catalog file name: ')
hospital_file = input('Enter hospital product catalog file name: ')

# ## Retrieve product details

# ### Manufacturer Product

# In[21]:


manufacturer_catalog=pd.read_csv("Data/"+manufacturer_file).dropna(how='all')
manufacturer_catalog.columns=manufacturer_catalog.columns.str.strip()
man_product_catalog=manufacturer_catalog[['Item number',
       'Description', 'Size', 'Gauge', 'Capacity', 'Color', 'BUOM', 'UM',
       'Base Price', 'PRODUCT_TYPE_ID', 'NAME', 'SHORT_DESCRIPTION',
       'PRODUCT_STATUS', 'IS_PACK', 'UNITS_IN_PACK', 'PRODUCT_CATEGORY',
       'MFG_DATE', 'EXPIRY_DATE', 'PRODUCT_IMAGE','Manufacturer']]
man_product_catalog=man_product_catalog.rename(columns=
                                               {'Item number':'PRODUCT_ID',
                                               'Description':'DESCRIPTION','Manufacturer':'MANUFACTURER', 'Size':'SIZE', 
                        'Gauge':'VOLUME', 'Color':'COLOR', 'BUOM':'WEIGHT_UOM', 'UM':'UOM',
       'PRODUCT_TYPE_ID':'PRODUCT_TYPE_ID', 'NAME':'NAME', 'SHORT_DESCRIPTION':'SHORT_DESCRIPTION',
       'PRODUCT_STATUS':'PRODUCT_STATUS', 'IS_PACK':'IS_PACK', 'UNITS_IN_PACK':'UNITS_IN_PACK', 
        'PRODUCT_CATEGORY':'PRODUCT_CATEGORY','MFG_DATE':'MFG_DATE', 'EXPIRY_DATE':'EXPIRY_DATE',
                                        'Base Price':'BASE_PRICE', 'PRODUCT_IMAGE':'PRODUCT_IMAGE'})



# ### Distributor Product

# In[22]:


distributor_catalog=pd.read_excel("/home/kaiwalya/Desktop/Neo4J/Product Data/"+distributor_file).dropna(how='all')


distr_product_catalog=distributor_catalog[['Account Name', 'Supplier Name',
       'Supplier SKU Number', 'Distributor SKU', 'SKU Description',
       'Hospital Item Number','Distributor Name']]
distr_product_catalog=distr_product_catalog.rename(columns=
            {'Account Name':'HOSPITAL_NAME', 'Supplier Name':'MANUFACTURER_NAME',
             'Supplier SKU Number':'PRODUCT_ID',
             'Distributor SKU':'DISTRIBUTOR_SKU', 'SKU Description':'DESCRIPTION',
       'Hospital Item Number':'HOSPITAL_SKU','Distributor Name':'DISTRIBUTOR_NAME'})


# ### Hospital product

# In[23]:


hospital_catalog=pd.read_excel("/home/kaiwalya/Desktop/Neo4J/Product Data/"+hospital_file).dropna(how='all')
hosp_product_catalog=hospital_catalog[['Distributor Name', 'Supplier Name',
       'Supplier SKU Number', 'Distributor SKU Number', 'SKU Description',
       'Hospital Item Number','Hospital Name']]
hosp_product_catalog=hosp_product_catalog.rename(columns=
            {'Distributor Name':'DISTRIBUTOR_NAME', 'Supplier Name':'MANUFACTURER_NAME',
       'Supplier SKU Number':'PRODUCT_ID', 'Distributor SKU Number':'DISTRIBUTOR_SKU', 
             'SKU Description':'DESCRIPTION',
       'Hospital Item Number':'HOSPITAL_SKU','Hospital Name':'HOSPITAL_NAME'})



# ### Generate Correlations

# In[24]:


correlation = []
unique_pids = man_product_catalog["PRODUCT_ID"].unique()
for pid in unique_pids:
    something = []
    df2_pid = distr_product_catalog[distr_product_catalog["PRODUCT_ID"] == pid]
    df2_pid = df2_pid[['DISTRIBUTOR_NAME','DISTRIBUTOR_SKU']].drop_duplicates()
    df2_d = df2_pid.to_dict(orient="records")

    df3_pid = hosp_product_catalog[hosp_product_catalog["PRODUCT_ID"] == pid]
    df3_pid = df3_pid[['HOSPITAL_NAME','HOSPITAL_SKU']].drop_duplicates()
    df3_d = df3_pid.to_dict(orient="records")

    for x in range(0,len(df2_d)):
        something.append(df2_d[x])
    for x in range(0,len(df3_d)):
        something.append(df3_d[x])
    

    correlation.append(something)
    
df4 = man_product_catalog.copy()
df4["CORRELATION"] = correlation
j = df4.to_json(orient="records")
j=json.loads(j)



product.insert_many(j)


