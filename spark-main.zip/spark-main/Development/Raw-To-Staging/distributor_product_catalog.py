import pymongo
from pymongo import MongoClient
import pprint
import pandas as pd
import json
import numpy as np
client = MongoClient("mongodb://127.0.0.1:27017")


# In[20]:


db=client.MED_EX_CHAIN
correlation=db.CORRELATION_DATA

distributor_file = input('Enter distributor product catalog file name: ')

distributor_catalog=pd.read_excel("Data/"+distributor_file).dropna(how='all').astype(str)


distr_product_catalog=distributor_catalog[['Account Name', 'Supplier Name',
       'Supplier SKU Number', 'Distributor SKU', 'SKU Description',
       'Hospital Item Number','Distributor Name','Contract Price','Contract Number','Unit Price']]
distr_product_catalog=distr_product_catalog.rename(columns=
            {'Account Name':'HOSPITAL_NAME', 'Supplier Name':'MANUFACTURER_NAME',
             'Supplier SKU Number':'PRODUCT_ID',
             'Distributor SKU':'DISTRIBUTOR_SKU', 'SKU Description':'DESCRIPTION',
       'Hospital Item Number':'HOSPITAL_SKU','Distributor Name':'DISTRIBUTOR_NAME','Contract Price':'CONTRACT_PRICE',
       'Contract Number':'CONTRACT_NUMBER','Unit Price':'BASE_PRICE'})

correlation_data = distr_product_catalog[['PRODUCT_ID','DISTRIBUTOR_NAME','DISTRIBUTOR_SKU','HOSPITAL_NAME','HOSPITAL_SKU'\
					,'MANUFACTURER_NAME','DESCRIPTION','CONTRACT_PRICE','CONTRACT_NUMBER','BASE_PRICE']]


correlation.insert_many(json.loads(correlation_data.to_json(orient='records')))
