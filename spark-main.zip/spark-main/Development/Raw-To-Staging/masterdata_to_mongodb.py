import pymongo
from pymongo import MongoClient
import pprint
import pandas as pd
import json as json
import numpy as np

# In[2]:


client = MongoClient("mongodb://127.0.0.1:27017")


# In[319]:


db=client.MED_EX_CHAIN
product=db.PRODUCT
manufacturer=db.MANUFACTURER
distributor=db.DISTRIBUTOR
hospital=db.HOSPITAL
user_roles=db.USER_ROLES


# In[243]:


manufacturer_csv = pd.read_csv("/home/kaiwalya/Desktop/Neo4J/Schema - Master Data/Manufacturer.csv").dropna(how="all")
manufacturer_csv
#manufacturer_csv = spark.read.csv("Schema - Master Data/Manufacturer.csv", header=True).dropna(how="all")
#manufacturer_csv.show()


# In[12]:


distributor_csv = pd.read_csv("/home/kaiwalya/Desktop/Neo4J/Schema - Master Data/Distributor.csv").dropna(how="all")
distributor_csv


# In[13]:


hospital_csv = pd.read_csv("/home/kaiwalya/Desktop/Neo4J/Schema - Master Data/Hospital.csv").dropna(how="all")
hospital_csv


# In[14]:


user_csv = pd.read_csv("/home/kaiwalya/Desktop/Neo4J/Schema - Master Data/User.csv").dropna(how="all")
user_csv


# ### Insert into mongodb with versions


manufacturer_json=json.loads(manufacturer_csv.to_json(orient='records'))
distributor_json=json.loads(distributor_csv.to_json(orient='records'))
hospital_json=json.loads(hospital_csv.to_json(orient='records'))
user_json=json.loads(user_csv.to_json(orient='records'))


# In[205]:


manufacturer.insert_many(manufacturer_json)
distributor.insert_many(distributor_json)
hospital.insert_many(hospital_json)
user_roles.insert_many(user_json)

# In[29]:


#manufacturer.drop()
#distributor.drop()
#hospital.drop()
#user_roles.drop()


