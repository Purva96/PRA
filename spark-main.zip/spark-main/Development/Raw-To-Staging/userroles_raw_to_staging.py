import json
import pprint
import numpy as np
import pandas as pd
from datetime import datetime
import pymongo
from pymongo import MongoClient
import findspark
findspark.init('/home/ubuntu/Product_MDM-STY/spark-3.1.1-bin-hadoop2.7')
import pyspark
from pyspark import SparkContext
from pyspark.sql.functions import *
from pyspark.sql import SparkSession, SQLContext
spark = SparkSession.\
        builder.\
        appName("pyspark-notebook2").\
        config("spark.executor.memory", "1g").\
        config("spark.jars.packages", "org.mongodb.spark:mongo-spark-connector_2.12:3.0.0").\
        getOrCreate()


client = MongoClient("mongodb://127.0.0.1:27017")
db = client.MED_EX_CHAIN
user_roles = db.USER_ROLES


file_name = input('Enter File Name: ')
user_csv = spark.read.csv("../Data/"+file_name, header = True).dropna(how = "all")
user_data = spark.read.format("mongo").option("uri",
                            "mongodb://127.0.0.1:27017/MED_EX_CHAIN.USER_ROLES").load()
user_data.createOrReplaceTempView('user_view')



for i in user_csv.toJSON().collect():
    new_record = json.loads(i)
    user_id = new_record['USER_ID']
    query = "select * from user_view \
             where USER_ID = '" + user_id + "' and\
                   VERSION = (select max(VERSION) from user_view \
             where USER_ID = '" + user_id + "')"
    available_data = spark.sql(query)
    print(user_id, available_data.count())
    
    if available_data.count() == 0: # no data available, insert with version 1.0
        insert_data = dict(new_record)
        insert_data['VERSION'] = 1.0
        insert_data['START_DATE'] = str(datetime.now())
        insert_data['END_DATE'] = str('9999-12-31')
        insert_data['LAST_UPDATE_DT'] = str(datetime.now())
        user_roles.insert_one(insert_data)
        print('insert data with 1 version.')
        
    elif (new_record['FIRST_NAME'] != available_data.rdd.collect()[0]['FIRST_NAME'])|\
         (new_record['USER_ADDRESS'] != available_data.rdd.collect()[0]['USER_ADDRESS'])|\
         (new_record['PHONE_NUMBER'] != available_data.rdd.collect()[0]['PHONE_NUMBER'])|\
	 (new_record['EMAIL_ID'] != available_data.rdd.collect()[0]['EMAIL_ID']): # add conditions for all the columns which are eligible for the SCD.
        user_roles.update_many({'USER_ID': user_id, 
                                 'VERSION': int(available_data.collect()[0].asDict()['VERSION'])},
                                  {"$set": {'LAST_UPDATE_DT': str(datetime.now()),
                                            'END_DATE': str(datetime.now())}})
        insert_data = dict(new_record)
        insert_data['START_DATE'] = str(datetime.now())
        insert_data['END_DATE'] = str('9999-12-31')
        insert_data['LAST_UPDATE_DT'] = str(datetime.now())
        insert_data['VERSION'] = int(available_data.collect()[0].asDict()['VERSION']) + 1
        user_roles.insert_one(insert_data)
        print('insert data with updated + 1 version.')
                
                 # insert data with new version.
    else:
        update_data = dict(new_record)
        update_data['LAST_UPDATE_DT'] = str(datetime.now())
        user_roles.update_one({'USER_ID': user_id, 
                                'VERSION': int(available_data.collect()[0].asDict()['VERSION'])},
                                 {"$set": update_data})
        print('update record with same latest version')  # update existing data with same version.
