import pymongo
from pymongo import MongoClient
import pprint
import pandas as pd
import json
import numpy as np
client = MongoClient("mongodb://127.0.0.1:27017")


# In[20]:


db=client.MED_EX_CHAIN
correlation=db.CORRELATION_DATA

hospital_file = input('Enter hospital product catalog file name: ')

hospital_catalog=pd.read_excel("/home/kaiwalya/Desktop/Neo4J/Product Data/"+hospital_file).dropna(how='all')
hosp_product_catalog=hospital_catalog[['Distributor Name', 'Supplier Name',
       'Supplier SKU Number', 'Distributor SKU Number', 'SKU Description',
       'Hospital Item Number','Hospital Name']]
hosp_product_catalog=hosp_product_catalog.rename(columns=
            {'Distributor Name':'DISTRIBUTOR_NAME', 'Supplier Name':'MANUFACTURER_NAME',
       'Supplier SKU Number':'PRODUCT_ID', 'Distributor SKU Number':'DISTRIBUTOR_SKU', 
             'SKU Description':'DESCRIPTION',
       'Hospital Item Number':'HOSPITAL_SKU','Hospital Name':'HOSPITAL_NAME'})


#correlation_data = distr_product_catalog[['PRODUCT_ID','DISTRIBUTOR_NAME','DISTRIBUTOR_SKU','HOSPITAL_NAME','HOSPITAL_SKU'\
#					,'MANUFACTURER_NAME','DESCRIPTION']]

#correlation.insert_many(json.loads(correlation_data.to_json(orient='records')))
