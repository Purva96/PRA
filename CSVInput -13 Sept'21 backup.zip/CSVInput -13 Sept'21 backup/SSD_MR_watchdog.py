import os.path,time
import datetime
import pathlib
from SSD_code_input import *
from runSSD import *
from MR_code_input import *
# fname = pathlib.Path('MR_Suncor_output_Sim.json') 
# mtime = datetime.datetime.fromtimestamp(fname.stat().st_mtime)
# print(mtime)
SSD_END_TIME= 0
MR_START_TIME = 0
MR_END_TIME = 0

import logging

# Create a logging instance
logger = logging.getLogger('my_application')
logger.setLevel(logging.INFO) # you can set this to be DEBUG, INFO, ERROR

# Assign a file-handler to that instance
fh = logging.FileHandler("Logfile.txt")
fh.setLevel(logging.INFO) # again, you can set this differently

# Format your logs (optional)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter) # This will set the format to the file handler

# Add the handler to your logging instance
logger.addHandler(fh)


try:
	SSD_START_TIME= time.time()/60	
	main_ssd()
	overall_ssd_tag_value=SSD_func()
	MR_csv_data= pd.read_csv(configur.get("SSD_code","MR_read_PHD_data_csvFile"),header=None,names= ["TagName","TimeStamp","Value","Confidence"], skiprows=[0,1])
	for column in MR_csv_data[["Confidence"]]:
		columnSeriesObj = MR_csv_data[column]
		column_data = columnSeriesObj.values
		print(column_data)

		if (column_data== 100).all():
			flag= 1
		else:
			flag = 0 

	print("overall_ssd_tag_value---",overall_ssd_tag_value)
	pros= subprocess.Popen(["C:\\Windows\\syswow64\\WindowsPowerShell\\v1.0\\powershell.exe","-ExecutionPolicy","Unrestricted",".\\SSD_Output_phd_data_Write.PS1"],stdout=sys.stdout)
	pros.communicate()
	SSD_END_TIME = time.time()/60
	SSD_TOTAL_EXECUTION_TIME = (SSD_END_TIME - SSD_START_TIME)

	if overall_ssd_tag_value > 0.8:    	
		MR_START_TIME = time.time()/60
		main_MR_func()
		MR_END_TIME = time.time()/60
		
		watchdog_flag = 1


	else:
		MR_START_TIME = 0
		MR_END_TIME = 0
		watchdog_flag = 0
		

	MR_TOTAL_EXECUTION_TIME = (MR_END_TIME - MR_START_TIME)
	with open("SSD_MR_watchdog_Flag.csv","w+",newline='') as file :
		writer= csv.writer(file)
		timestamp =  int(datetime.now().timestamp())
		utc_timestamp = datetime.utcfromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")
		writer.writerow(["tagname","timestamp","value"])
		writer.writerow(["XI_CDUVDU_01_MRWD.PV_RW",utc_timestamp,watchdog_flag])
		writer.writerow(["XI_CDUVDU_01_SSDTIME.PV_RW",utc_timestamp,SSD_TOTAL_EXECUTION_TIME])
		writer.writerow(["XI_CDUVDU_01_MRTIME.PV_RW",utc_timestamp,MR_TOTAL_EXECUTION_TIME])
		writer.writerow(["XI_CDUVDU_01_MRDTCONF.PV_RW",utc_timestamp,flag])
		writer.writerow(["SSD code START time ",utc_timestamp,SSD_START_TIME])
		writer.writerow(["SSD code END time",utc_timestamp,SSD_END_TIME])
		writer.writerow(["MR code START TIME",utc_timestamp,MR_START_TIME])
		writer.writerow(["MR code END TIME",utc_timestamp,MR_END_TIME])

	pros= subprocess.Popen(["C:\\Windows\\syswow64\\WindowsPowerShell\\v1.0\\powershell.exe","-ExecutionPolicy","Unrestricted",".\\watchdog_flag1.PS1"],stdout=sys.stdout)
	pros.communicate()



except Exception as e:
	logger.exception(e)
	watchdog_flag = 2
	SSD_TOTAL_EXECUTION_TIME = (SSD_END_TIME - SSD_START_TIME)
	MR_TOTAL_EXECUTION_TIME = (MR_END_TIME - MR_START_TIME)
	with open("SSD_MR_watchdog_Flag.csv","w+",newline='') as file :
		writer= csv.writer(file)
		timestamp =  int(datetime.now().timestamp())
		utc_timestamp = datetime.utcfromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")
		writer.writerow(["tagname","timestamp","value"])
		writer.writerow(["XI_CDUVDU_01_MRWD.PV_RW",utc_timestamp,watchdog_flag])
		writer.writerow(["XI_CDUVDU_01_SSDTIME.PV_RW",utc_timestamp,SSD_TOTAL_EXECUTION_TIME])
		writer.writerow(["XI_CDUVDU_01_MRTIME.PV_RW",utc_timestamp,MR_TOTAL_EXECUTION_TIME])

		writer.writerow(["SSD code START time ",utc_timestamp,SSD_START_TIME])
		writer.writerow(["SSD code END time",utc_timestamp,SSD_END_TIME])
		writer.writerow(["MR code START TIME",utc_timestamp,MR_START_TIME])
		writer.writerow(["MR code END TIME",utc_timestamp,MR_END_TIME])

	pros= subprocess.Popen(["C:\\Windows\\syswow64\\WindowsPowerShell\\v1.0\\powershell.exe","-ExecutionPolicy","Unrestricted",".\\watchdog_flag1.PS1"],stdout=sys.stdout)
	pros.communicate()
	

