import json
import re
from datetime import datetime 
from tagclass import SteadyStateTag
from commonclass import CommonSteadyStates
import csv
from configparser import ConfigParser


configur = ConfigParser()
print (configur.read('config.ini'))


def convert_json(json_input):
    # Parse input JSON data from input
    
    input = json.loads(json_input)
    
    job_id = input['JobId']
    model_id = input['ModelId']
    calculation_type = input['CalculationType']
    configuration = input['Configuration']
    input_data_list = input['InputDataList']
    output_data_list = input['OutputDataList']

    #Get global SSD parameters:
    global_input = {
        "OD_window_size" : input["Configuration"]["OD_window_size"],
        "OD_alpha" : input["Configuration"]["OD_alpha"],
        "OD_window_position" : input["Configuration"]["OD_window_position"], #replaced by Forge config?
        "interpolated_minute" : input["Configuration"]["interpolated_minute"], #replaced by Forge config?
        "noise" : input["Configuration"]["noise"],
        "SS_alpha" : input["Configuration"]["SS_alpha"],
        "SS_window_position" : input["Configuration"]["SS_window_position"], #replaced by Forge config?
        "SS_window_size" : [],
        "likelihood_requirement" : []
        }

    #create list of sensor tags
    #Get Sensor Tag Names
    sensor_tags = []
    output_tags = []

    for data_sets in input_data_list:
        sensor_tags.append(data_sets['tagName'])

    for tags in output_data_list:
        output_tags.append(tags['tagName'])

    input_rawdata = {}
    #Create new list of dictionaries with inputs and data for each tag
    for tag in sensor_tags:
        input_rawdata[tag] = {}
        input_rawdata[tag]['sensor_input'] = global_input.copy()

        for key, value in configuration.items(): 
            if tag == value:         
                tag_key_number = re.findall(r'\d+', key)
            
                input_rawdata[tag]['sensor_input']["SS_window_size"] = int(configuration['CRITICAL_TAG_'+tag_key_number[0]+"_WINODW_SIZE"]) #change to parse by tag name in config
                input_rawdata[tag]['sensor_input']["likelihood_requirement"] = int(configuration['CRITICAL_TAG_'+tag_key_number[0]+"_LIKELIHOOD_REQ"])/100 #change to parse by tag name in config

        for inputs in input_data_list:
            if inputs["tagName"] == tag:
                #input_rawdata[tag]["tagCheck"] = tag
                input_rawdata[tag]["data"] = inputs["timeStampsToValueMap"]

    return job_id, model_id, calculation_type, configuration, sensor_tags, input_rawdata, output_tags


def get_steady_states(tag_name, raw_data):
    """Get steady state data points for a single tag."""

    # get raw sensor data from the local cache database
    inputs = raw_data[tag_name]["sensor_input"]
    times = [float(i) for i in raw_data[tag_name]["data"].keys()]
    data = [float(i) for i in raw_data[tag_name]["data"].values()]
    
    # get input parameters
    #name = inputs["name"]
    name = tag_name
    OD_window_size = inputs["OD_window_size"]
    OD_alpha = inputs["OD_alpha"]
    OD_window_position = inputs["OD_window_position"]
    interpolated_minute = inputs["interpolated_minute"]
    noise = inputs["noise"]
    SS_window_size = inputs["SS_window_size"]
    SS_alpha = inputs["SS_alpha"]
    SS_window_position = inputs["SS_window_position"]
    likelihood_requirement = inputs["likelihood_requirement"]
    
    # run steady state analysis
    tag = SteadyStateTag(times, data, name)
    tag.remove_outliers(OD_window_size, OD_alpha, OD_window_position)
    tag.change_frequency(interpolated_minute, noise)
    tag.get_SS_likelihood(SS_window_size, SS_alpha, SS_window_position)
    tag.get_SS_signal(likelihood_requirement)
    tag.get_SS_time_ranges()
    
    return tag


# def get_all_steady_states_parallel(sensor_tags, raw_data):
#     """Get steady state data points for all tags in parallel."""
    
#     # get all tag data
#     pool = mp.Pool(mp.cpu_count())
#     all_tags = pool.starmap(get_steady_states, [(x, y) 
#             for x, y in zip(sensor_tags, raw_data)])
#     pool.close()
#     pool.join()
    
#     return all_tags


def get_all_steady_states_series(sensor_tags, raw_data):
    """Get steady state data points for all tags in series."""
    
    all_tags = []
    for i in range(len(sensor_tags)):
        print("Processing Tag: " + sensor_tags[i])
        tag = get_steady_states(sensor_tags[i], raw_data)
        all_tags.append(tag)
    
    return all_tags


def get_common_steady_states(all_tags, lab_tags, min_SS_length_hour, 
    min_number_labs):
    """Get common steady states across all tags."""

    common = CommonSteadyStates(all_tags)
    common.get_steady_lengths()
    #common.get_labs_per_steady_range(lab_tags)
    #common.get_passing_steady_ranges(min_SS_length_hour, min_number_labs)

    return common


def package_results(job_id, model_id, calculation_type, all_tags, common, output_tags):

    json_output = {}

    json_output["JobId"] = job_id
    json_output["ModelId"] = model_id
    json_output["CalculationType"] = calculation_type
    json_output["Configuration"] = {}

    

    #---------------------------------------------------------------------#
    # Build Output Data Set for Each Process Tag
    #---------------------------------------------------------------------#

    i = 0
    Results = []
    for tags in all_tags:

        tag_results = {}
        tag_results["tagName"] = output_tags[i]

        tag_results["output_data"] = {}

        for j in range(len(tags.final_times)):
            tag_results["output_data"][tags.final_times[j]] = tags.signal[j]

        tag_results["outputConfiguration"] = {}

        Results.append(tag_results)
        i = i + 1

    #---------------------------------------------------------------------#
    # Build Output Data Set for Unit Level Steady State
    #---------------------------------------------------------------------#

    unit_results = {}
    unit_results["tagName"] = output_tags[i]
    unit_results["output_data"] = {}

    for times in all_tags[0].final_times:
        for low, high in common.steady_ranges:
            if low <= times <= high:
                unit_results["output_data"][times] = 1
            else:
                unit_results["output_data"][times] = 0


    Results.append(unit_results)

    json_output["OutputDataList"] = Results

    return json_output


def runSSD(json_input,SUM_OF_SSD_FLAG=0):
    job_id, model_id, calculation_type, configuration, sensor_tags, input_rawdata, output_tags = convert_json(json_input)

    #mp.freeze_support()
    #all_tags = get_all_steady_states_parallel(sensor_tags, input_rawdata)

    lab_tags = []
    min_SS_length_hour = 2
    min_number_labs = 0

    all_tags = get_all_steady_states_series(sensor_tags, input_rawdata)

    print('Getting Common Steady States')

    common = get_common_steady_states(all_tags, lab_tags, min_SS_length_hour, 
            min_number_labs)

    json_output = package_results(job_id, model_id, calculation_type, all_tags, common, output_tags)
    
    
	
    with open(configur.get("SSD_code","SSD_write_PHD_data_csvFile"),'a',newline= '') as f:
        writer= csv.writer(f)
        writer.writerow(["tagname","timestamp","value"])
        for i in range(0, len(sensor_tags)+1):
            new_dict=json_output['OutputDataList'][i]
            new_tag_name= new_dict['tagName']
            try:
                print("Writing in csv file ",new_tag_name)
                length=len(new_dict['output_data'])	
                print("Total values------------",length)
                latest_value=list(new_dict['output_data'].items())[length-1][1]
                print("Latest_Value----------",latest_value)
                print(type(latest_value))
                epoch_Time = list(new_dict['output_data'].items())[length-1][0]
                timestamp=datetime.utcfromtimestamp(epoch_Time).strftime("%Y-%m-%d %H:%M:%S")
                print(type(latest_value))
                SUM_OF_SSD_FLAG+=int(latest_value)
                writer.writerow([new_tag_name,timestamp,latest_value])
            except:
                pass
        print("SUM_OF_SSD_FLAG----",SUM_OF_SSD_FLAG)
        print("len(sensor_tags", len(sensor_tags))
        otag_value=SUM_OF_SSD_FLAG/len(sensor_tags)	
            
            # for key,value in new_dict['output_data'].items():
            # #             print(key,value)
            #     timestamp=datetime.utcfromtimestamp(key).strftime("%Y-%m-%d %H:%M:%S")
            #     #f.write('{},{},{}\r'.format(new_tag_name,timestamp,value)
            #     writer.writerow([new_tag_name,timestamp,value])
       
    return json_output, all_tags, common,otag_value