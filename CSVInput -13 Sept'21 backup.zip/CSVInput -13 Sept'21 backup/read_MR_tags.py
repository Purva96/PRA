import subprocess,sys
import xlrd
import pandas as pd
import csv
from configparser import ConfigParser


configur = ConfigParser()
print (configur.read('config.ini'))


input_file= configur.get("SSD_code","Input_Configuration_file")
rb = xlrd.open_workbook(input_file)
sheetNames = rb.sheet_names()

def read_MR_Tags():
    edge_asset_values = []
    output_tags=[]
    GE_output_tags = []
    edge_name_keys = []
    edge_name_values = []
    edge_asset_keys = []
    edge_asset_values_1 =[]
    a=b=1
    for name in sheetNames:
        if name == "Data Reconciliation":
            sheet=rb.sheet_by_name(name)
            for i in range(sheet.nrows):
                if sheet.cell_value(i,1) != '' and sheet.cell_value(i,4) != 'Tag Name':
                    edge_asset_keys.append("EDGE%d_ASSET"%(b))
                    edge_asset_values_1.append(sheet.cell_value(i,4).split(".")[0])
                    
                    b+=1
                if sheet.cell_value(i,1) != '' and sheet.cell_value(i,5) != 'Output Tags':
                    output_tags.append(sheet.cell_value(i,5).split(".")[0])
                if sheet.cell_value(i,1) != '' and sheet.cell_value(i,6) != 'Gross Error Output_ Tags':
                    GE_output_tags.append(sheet.cell_value(i,6).split(".")[0])
                    
                edge_name=sheet.cell_value(i,1)+sheet.cell_value(i,2)
                if edge_name != '' and edge_name !='Start NodeEnd Node': 
                    edge_name_keys.append("EDGE%d_NAME"%(a))
                    edge_name_values.append(edge_name)
                    a+=1
                else:
                    pass
     

    with open(configur.get("Read_MR_Tags","MR_Input_Tags"),"w",newline="") as outfile:
            writer=csv.writer(outfile)
            writer.writerow(["phd_host","phdtag"])

            for tagg in edge_asset_values_1:
                if tagg != "":
                    tagg_name_pvrw= tagg+".PV_RW"
                    writer.writerow(["localhost",tagg_name_pvrw])
                    tagg_name_stdev=tagg+".STDEV"
                    writer.writerow(["localhost",tagg_name_stdev])
    with open(configur.get("Read_MR_Tags","MR_Output_Tags"),"w",newline="") as outfile:
            writer=csv.writer(outfile)
            writer.writerow(["phdtag"])
            for tag in output_tags:
                if tag != "":                    
                    writer.writerow([tag+".PV_AG"])
            for GE_tag in GE_output_tags:
                if GE_tag != "":                    
                    writer.writerow([GE_tag+".CL_ECPR"])
                    
    return (edge_asset_keys,edge_asset_values_1,edge_name_keys,edge_name_values,output_tags,GE_output_tags)
