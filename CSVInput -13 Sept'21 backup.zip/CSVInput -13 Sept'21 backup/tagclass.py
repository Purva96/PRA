import numpy as np
from scipy.stats import t

class SteadyStateTag:
    """Class containing methods used for steady state tags.
    
    Inputs:
    
    times : list of integers
        list of raw times (seconds since epoch) corresponding to raw data points
    data : list of floats
        list of raw data points on which to do steady state analysis
    name : string
        name identifying the data in each tag
    """

    def __init__(self, times, data, name):
        self.raw_times = times
        self.raw_data = data
        self.name = name

    def remove_outliers(self, OD_window_size, OD_alpha, OD_window_position):
        """Detect and remove outliers.
        
        Inputs:
        
        OD_window_size : integer
            the window size for Outlier Detection. Value should be an odd 
            integer > 0.
        OD_alpha : float
            the probability associated with the two-tailed Student's 
            t-distribution for Outlier Detection. Value should be in the range 
            (0, 1].
        OD_window_position : float
            the fraction within the window where the target point to be 
            evaluated is. For endpoint: value = 1.0, for midpoint: value = 0.5.
        """
        
        times_in = self.raw_times
        data_in = self.raw_data
        window_size = int(OD_window_size)
        window_position = OD_window_position
        alpha = OD_alpha
        
        if window_position == 0.5 and window_size % 2 != 1:
            window_size = window_size + 1
        elif window_position in [0.25, 0.75] and window_size %4 != 1:
            mod_window_size = window_size % 4
            if mod_window_size == 0:
                window_size = window_size + 1
            else:
                window_size = window_size + 5 - mod_window_size
        
        #student t-distribution for 2-tailed distribution
        t_value = t.ppf(1 - alpha / 2, window_size - 1)
        
        target_point = int((window_size - 1) * window_position)
        weights = ([target_point + 1 - abs(target_point - x) for x in 
            range(window_size)])
        num_points = len(times_in)
        
        times_out = []
        data_out = []
        
        # add fake 0 at beginning so below for loop works for first loop too
        # faster to update this value as window moves than to recalculate
        OD_data = [0] + data_in[:window_size-1]
        
        for i in range(num_points - window_size + 1):
            OD_data = OD_data[1:] + [data_in[window_size - 1 + i]]
            weighted_average = (sum(x * y for x, y in zip(OD_data, weights)) / 
                sum(weights))
            st_dev = np.std(OD_data)
            bounds = t_value * st_dev * np.sqrt(1 + 1 / window_size)
            if (abs(data_in[target_point + i] - weighted_average) <= bounds):
                times_out.append(times_in[target_point + i])
                data_out.append(data_in[target_point + i])
        
        self.clean_times = times_out
        self.clean_data = data_out


    def change_frequency(self, interpolated_minute, noise):
        """Change time and data frequency by interpolating and adding noise.
        
        Inputs:
        
        interpolated_minute : integer
            the desired time interval in minutes for the interpolated data.
            Value should be >= 1.
        noise : float
            the percent noise to add to the interpolated data. Value should be 
            > 0. For example, a value of 0.02 produces 2% noise.
        """
        
        try:
            times_in = self.clean_times
            data_in = self.clean_data
        except (AttributeError):
            times_in = self.raw_times
            data_in = self.raw_data
        
        interval = interpolated_minute
        noise = noise
        num_times_in = len(times_in)
        delta_times_out = interval * 60
        print("times_in ------------------------",times_in)
        times_out = [times_in[0]]
        data_out = [data_in[0]]
        
        for i in range(1, num_times_in):
            delta_times_in = times_in[i] - times_in[i-1]
            if delta_times_in > delta_times_out:
                num_steps = round(delta_times_in / delta_times_out)
                step_data = (data_in[i] - data_in[i-1]) / num_steps
                for j in range(1, num_steps):
                    times_out.append(times_out[-1] + delta_times_out)
                    data_out.append((data_in[i-1] + step_data * j) 
                        * np.random.normal(1, noise))
                times_out.append(times_in[i])
                data_out.append(data_in[i])
            else:
                times_out.append(times_in[i])
                data_out.append(data_in[i])
        
        self.interpolated_times = times_out
        self.interpolated_data = data_out


    def get_SS_likelihood(self, SS_window_size, SS_alpha, SS_window_position):
        """Determine steady state likelihood for each point.
        
        Inputs:
        
        SS_window_size : integer
            the window size for Steady State Detection. Value should be an odd 
            integer > 0.
        SS_alpha : float
            the probability associated with the Student's t-distribution for 
            Steady State Detection. Value should be in the range (0, 1].
        SS_window_position : float
            the fraction within the window where the target point to be 
            evaluated is. For endpoint: value = 1.0, for midpoint: value = 0.5.
        """
        
        try:
            times_in = self.interpolated_times
            data_in = self.interpolated_data
        except (AttributeError):
            try:
                times_in = self.clean_times
                data_in = self.clean_data
            except (AttributeError):
                times_in = self.raw_times
                data_in = self.raw_data
        
        window_size = SS_window_size
        alpha = SS_alpha
        window_position = SS_window_position
        
        if window_position in [0, 1]:
            pass
        elif window_position == 0.5:
            if window_size % 2 != 1:
                window_size = window_size + 1
        elif window_position in [0.25, 0.75]:
            mod_window_size = window_size % 4
            if mod_window_size == 1:
                pass
            elif mod_window_size == 0:
                window_size = window_size + 1
            else:
                window_size = window_size + 5 - mod_window_size
        
        #student t-distribution for 2-tailed distribution
        t_value = t.ppf(1 - alpha / 2, window_size - 1)
        
        target_point = int((window_size - 1) * window_position)
        num_points = len(times_in)
        relative_times_in = [(x - times_in[0]) for x in times_in]
        
        end = -(window_size - target_point - 1)
        if end == 0: end = None
        final_times = times_in[target_point:end]
        final_data = data_in[target_point:end]
        standard_deviation = []
        dc_standard_deviation = []
        likelihood = []
        
        # add fake 0 at beginning so below for loop works for first loop too
        # way faster to update these values as window moves than to recalculate
        SS_times = [0] + relative_times_in[:window_size-1]
        SS_data = [0] + data_in[:window_size-1]
        sum_xy = sum([x * y for x, y in zip(SS_times, SS_data)])
        sum_x = sum(SS_times)
        sum_y = sum(SS_data)
        sum_x2 = sum([x**2 for x in SS_times])
        
        for i in range(num_points - window_size + 1):
            old_time = SS_times.pop(0)
            old_data = SS_data.pop(0)
            new_time = relative_times_in[window_size - 1 + i]
            new_data = data_in[window_size - 1 + i]
            SS_times.append(new_time)
            SS_data.append(new_data)
            standard_deviation.append(np.std(SS_data))
            
            #faster to calculate slope this way than use linregress, same result
            sum_xy = sum_xy - old_time * old_data + new_time * new_data
            sum_x = sum_x - old_time + new_time
            sum_y = sum_y - old_data + new_data
            sum_x2 = sum_x2 - old_time**2 + new_time**2
            slope = ((window_size * sum_xy - sum_x * sum_y) / 
                    (window_size * sum_x2 - sum_x**2))
            
            drift_corrected_data = ([SS_data[j] - slope * (SS_times[j] 
                - SS_times[target_point]) for j in range(window_size)])
            dc_average = np.mean(drift_corrected_data)
            dc_stdev = np.std(drift_corrected_data)
            dc_standard_deviation.append(dc_stdev)
            hypothesis_test = 0
            for j in range(window_size):
                if (abs(SS_data[j] - dc_average) <= dc_stdev * t_value):
                    hypothesis_test = hypothesis_test + 1
            likelihood.append(hypothesis_test / window_size)
        
        self.final_times = final_times
        self.final_data = final_data
        self.stdev = standard_deviation
        self.dc_stdev = dc_standard_deviation
        self.likelihood = likelihood


    def get_SS_signal(self, likelihood_requirement):
        """Determine which points are considered to be at steady state.
        
        Inputs:
        
        likelihood_requirement : float
            the lower threshold for the percent chance that a data point is 
            considered to be at steady state. Value should be in the range 
            (0, 1].
        """
        
        likelihood = self.likelihood
        likelihood_req = likelihood_requirement
        
        SS_signal = []
        for like in likelihood:
            if like >= likelihood_req:
                SS_signal.append(1)
            else:
                SS_signal.append(0)
        
        self.signal = SS_signal


    def get_SS_time_ranges(self):
        """Determine time ranges over which the points are at steady state.
        
        Inputs: none
        """
        
        times = self.final_times
        signal = self.signal
        
        previous_signal = 0
        steady_ranges = []
        for i in range(len(times)):
            if signal[i] != previous_signal:
                if signal[i] == 1:
                    start_time = times[i]
                else:
                    end_time = times[i-1]
                    steady_ranges.append((start_time, end_time))
            previous_signal = signal[i]
        if previous_signal == 1:
            end_time = times[-1]
            steady_ranges.append((start_time, end_time))
        
        self.steady_ranges = steady_ranges


