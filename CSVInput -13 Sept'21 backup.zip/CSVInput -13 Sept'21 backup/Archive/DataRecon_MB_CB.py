import json
import numpy as np
import pandas as pd
import scipy.stats as st
import xlrd
import openpyxl
from openpyxl.utils.dataframe import dataframe_to_rows
import re
from datetime import datetime
import csv
from configparser import ConfigParser


configur = ConfigParser()
print (configur.read('config.ini'))

def read_data(json_input):
    #---------------------------------------------------------------------------
    # Parse input JSON data
    #---------------------------------------------------------------------------
    
    input = json.loads(json_input)
    
    job_id = input['JobId']
    model_id = input['ModelId']
    calculation_type = input['CalculationType']
    configuration = input['Configuration']
    input_data_list = input['InputDataList']
    output_data_list = input['OutputDataList']
    
    comp_indicator = configuration['COMPONENT_INDICATOR']
    total = configuration['TOTAL_COMPONENTS']
    interunit_indicator = configuration['INTERUNIT_INDICATOR']
    terminal_indicator = configuration['TERMINAL_INDICATOR']
    reaction_indicator = configuration['REACTION_INDICATOR']
    
    nodes = []
    edges = []
    unmeasured = []
    compmeas = []
    termbalin = []
    termbalout = []
    map = {}
    measurements = {}
    variance = {}
    index_order = ['TotalFlow']
    comp_key = 'TotalFlow'  # with multiple comp_keys, this would go below
    
    # get map of tag_name, component, start_node, end_node, edge from FORGE
    # get nodes and edges lists
    # initialize measurements and variance dictionaries 
    for key, value in configuration.items():
        m = re.match(r'EDGE([0-9]+)_([A-Z]+)', key)
        if not m: continue
        num = m[1]
        attr = m[2]
        if num not in map:
            map[num] = {}
            map[num]['component'] = comp_key
        if attr == 'ASSET':
            tag_name = value
            map[num]['tag_name'] = tag_name
        elif attr == 'NAME':
            edge = value
            start_node = edge[:len(edge)//2]
            end_node = edge[len(edge)//2:]
            if start_node not in nodes: nodes.append(start_node)
            if end_node not in nodes: nodes.append(end_node)
            if edge in edges:
                tmp_edge = edge + "1"
                i = 1
                while tmp_edge in edges:
                    i = i + 1
                    tmp_edge = tmp_edge[:-1] + str(i)
                    if i == 10: i = 0
                edge = tmp_edge
            edges.append(edge)
            measurements[edge] = {}
            variance[edge] = {}
            map[num]['start_node'] = start_node
            map[num]['end_node'] = end_node
            map[num]['edge'] = edge
            map[num]['data_model_revision'] = "" # updated later with a letter
            map[num]['has_Measurement'] = False # initialize,to be updated later
            map[num]['has_Variance'] = False # initialize, to be updated later
            map[num]['has_GEDFlag'] = False # initialize, to be updated later
            
    # get measurement and variance from FORGE InputDataList
    # update map attributes has_Measurement and has_Variance
    for input in input_data_list:
        tag_name = input['tagName']
        value_map = input['timeStampsToValueMap']
        if value_map == {}: continue
        value = list(value_map.values())[0]
        tag_begin, tag_end = tag_name.split('.')
        for num, stream in map.items():
            if stream['tag_name'] == tag_begin:
                stream_key = stream['edge']
                comp_key = stream['component']
                if tag_end.upper() == 'PV_CR':
                    stream['data_model_revision'] = 'D'
                    stream['has_Measurement'] = True
                    measurements[stream_key][comp_key] = value
                elif tag_end.upper() == 'PV_RW':
                    stream['data_model_revision'] = 'Suncor'
                    stream['has_Measurement'] = True
                    measurements[stream_key][comp_key] = value
                elif tag_end == 'FlowMass_CorrectedAggregated[SteadyState]':
                    stream['data_model_revision'] = 'F'
                    stream['has_Measurement'] = True
                    measurements[stream_key][comp_key] = value
                elif tag_end.upper() == 'STDEV':
                    stream['has_Variance'] = True
                    variance[stream_key][comp_key] = value
                elif tag_end == 'FlowMassStandardDeviation_CorrectedAggregated[SteadyState]':
                    stream['has_Variance'] = True
                    variance[stream_key][comp_key] = value
                break
    
    # get unmeasured list
    for num, stream in map.items():
        if (stream['has_Measurement'] == False or 
                stream['has_Variance'] == False):
            unmeasured.append(stream['edge'])
    
    # update map attribute has_GEDFlag from FORGE OutputDataList
    for output in output_data_list:
        tag_name = output['tagName']
        tag_begin, tag_end = tag_name.split('.')
        if (tag_end != 'FlowMass_GEDFlag' and 
                tag_end != 'FlowMassFlagGrossError_Reconciled[SteadyState]' 
                    and tag_end != 'CL_ECPR'):
            continue
        for num, stream in map.items():
            if stream['tag_name'] == tag_begin:
                stream['has_GEDFlag'] = True
                break
    
    df_measurements = pd.DataFrame(measurements, index = index_order)
    df_variance = pd.DataFrame(variance, index = index_order)
    
    # get termbalin and termbalout lists
    node_length = len(nodes[0])
    nodein = []
    nodeout = []
    for node in nodes:
        is_in_node = True
        is_out_node = True
        for edge in edges:
            if edge[:node_length] == node:
                is_out_node = False
            if edge[node_length:2*node_length] == node:
                is_in_node = False
            if is_in_node == False and is_out_node == False:
                break
        if is_in_node:
            nodein.append(node)
        if is_out_node:
            nodeout.append(node)
    for edge in edges:
        if edge[:node_length] in nodein:
            termbalin.append(edge)
        if edge[node_length:2*node_length] in nodeout:
            termbalout.append(edge)
    
    edges = pd.Series(edges)
    unmeasured = pd.Series(unmeasured)
    compmeas = pd.Series(compmeas)
    
    #---------------------------------------------------------------------------
    # Set Up Total Mass Balance Measurements, Variance and Labeling
    #---------------------------------------------------------------------------
    #---------------------------------------------------------------------------
    #Set Up Measurement Vector
    #---------------------------------------------------------------------------
    measured_mass = df_measurements.iloc[0]

    for index in measured_mass.index:
        measured_mass.rename(index={index:index+'_0'}, inplace=True)
    
    measured_mass[measured_mass < 1e-10] = 1e-10
    
    #---------------------------------------------------------------------------
    #Set Up Unmeasured Edges Vector
    #---------------------------------------------------------------------------
    unmeasured_edges = []
    
    for streams in unmeasured.values:
        needed_col = [col for col in measured_mass.index if streams in col]
        unmeasured_edges = unmeasured_edges + list(needed_col)
    
    unmeasured_mass = pd.Series(unmeasured_edges)
    
    #---------------------------------------------------------------------------
    #Set Up Variance Vector
    #---------------------------------------------------------------------------
    massvariance = df_variance.iloc[0]
    
    for index in massvariance.index:
        massvariance.rename(index={index:index+'_0'}, inplace=True)
    
    massvariance[massvariance < 1e-7] = 1e-7

    all_edges_mass = massvariance.index.values
    all_edges_mass = pd.Series(all_edges_mass) 
    
    measured_comp = []
    compvariance = []
    all_edges_var = []
    unmeasured_comp = []
    
    #---------------------------------------------------------------------------
    # Set Up Measurements, Variance and Labeling for Compositions
    #---------------------------------------------------------------------------
    if comp_indicator == 1:
        measured_comp = pd.Series()
        compvariance = pd.Series()

        #-----------------------------------------------------------------------
        #Set Up Measurement and Variance Vector
        #-----------------------------------------------------------------------

        for edge in edges:
            comp_data = df_measurements[edge]
            comp_data = comp_data.dropna()

            comp_var = df_variance[edge]
            comp_var = comp_var.dropna()

            if len(comp_data) > 1:
                for i in range(total):
                    comp_data.rename(index={i:edge+'_'+str(i)}, inplace=True)
                    comp_var.rename(index={i:edge+'_'+str(i)}, inplace=True)
                datain = comp_data.drop(labels = edge+'_0')
                varin = comp_var.drop(labels = edge+'_0')                
            else:
                continue

            measured_comp = measured_comp.append(datain)
            compvariance = compvariance.append(varin)

        measured_comp[measured_comp < 1e-10] = 1e-10
        compvariance[compvariance < 1e-10] = 1e-10

        all_edges_var = compvariance.index.values
        all_edges_var = pd.Series(all_edges_var) 

        #-----------------------------------------------------------------------
        #Set Up Unmeasured Edges Vector
        #-----------------------------------------------------------------------
        unmeasured_comp_edges = []

        for streams in unmeasured.values:
            needed_col = [col for col in measured_comp.index if streams in col]
            unmeasured_comp_edges = unmeasured_comp_edges + list(needed_col)

        unmeasured_comp = pd.Series(unmeasured_comp_edges)

    return job_id, model_id, calculation_type, map, nodes, edges, all_edges_mass, measured_mass, massvariance, unmeasured_mass, measured_comp, compvariance, unmeasured_comp, all_edges_var, comp_indicator, interunit_indicator, terminal_indicator, reaction_indicator, total, compmeas, termbalin, termbalout

def connectivity(nodes, edges, all_edges, comp_indicator, interunit_indicator, 
    terminal_indicator, reaction_indicator, total, termbalin, termbalout):
    
    #---------------------------------------------------------------------------
    # Create the connectivity matrix 'connect'
    #---------------------------------------------------------------------------
    lennode = len(nodes[0])
    numnode = len(nodes)
    numedge = len(edges)
    numalledge = len(all_edges)

    if comp_indicator == 0:

        connect = np.zeros((int(numnode),int(numalledge)))

        column = 0
        row = 0

        #-----------------------------------------------------------------------
        # Assign connectivity values (-1, 0, 1) based on being an 
        # (output, not applicable, input)
        #-----------------------------------------------------------------------
        for i in nodes:
            for j in all_edges:
                if j[:lennode] == i:
                    connect[row][column] = -1
                    column = column + 1
                elif j[lennode:2*lennode] == i:
                    connect[row][column] = 1
                    column = column + 1
                else:
                    connect[row][column] = 0
                    column = column + 1
            else: 
                column = column + 1
            row = row + 1
            column = 0
    
        #-----------------------------------------------------------------------
        #Remove row corresponding to input and output nodes:
        #-----------------------------------------------------------------------
        i = 0
        for rows in connect:
            if np.sum(rows**2) > 1:
                connect[i]
            else:
                connect[i][:] = 'NaN'
            i = i+1

        dfmassconnect = pd.DataFrame(connect, columns = all_edges)
        dfmassconnect = dfmassconnect.dropna()

        total_connect = dfmassconnect

    else:
        connect_comp = pd.DataFrame(columns = all_edges)

        if interunit_indicator == 1:
            #-------------------------------------------------------------------
            # Build component connectivity matrix for interunit compositions 
            # balances
            #-------------------------------------------------------------------
            for num in range(0,total-1):

                intercompconnect = np.zeros((numnode,numalledge))

                row = 0
                column = 0
                k = 0

                for i in nodes:
                    for j in all_edges:
                        number = j.split('_')[1]
                        #number = re.findall(r'_([0-9]+)',j)[0]
                        if number == str(num):
                            if j[:lennode] == i:
                                intercompconnect[row][column] = -1
                                column = column + 1
                            elif j[lennode:2*lennode] == i:
                                intercompconnect[row][column] = 1
                                column = column + 1
                            else:
                                intercompconnect[row][column] = 0
                                column = column + 1
                        else: 
                            column = column + 1
                        k = k+1
                    row = row + 1
                    column = 0

                i = 0
                for rows in intercompconnect:
                    if (np.sum(rows**2) > 1 and 1 in intercompconnect[i,:] and 
                            -1 in intercompconnect[i,:]):
                        intercompconnect[i]
                    else:
                        intercompconnect[i][:] = 'NaN'
                    i = i+1

                dfintercompconnect = pd.DataFrame(intercompconnect, 
                    columns = all_edges)
                dfintercompconnect = dfintercompconnect.dropna()

                connect_comp = connect_comp.append(dfintercompconnect, 
                    ignore_index = True)

        if terminal_indicator == 1:
            #-------------------------------------------------------------------
            # Build component connectivity matrix for terminal composition 
            # balances
            #-------------------------------------------------------------------
            terminalcompconnect = np.zeros((total,numalledge))

            row = 0

            for num in range(1,total-1):
                column = 0

                for j in all_edges:
                    number = j.split('_')[1]
                    #number = re.findall(r'_([0-9]+)',j)[0]
                    #print(j.startswith(tuple(termbalin)), number)
                    if number == str(num):
                        if j.startswith(tuple(termbalin)) == True:
                            terminalcompconnect[row][column] = 1
                            column = column + 1
                        elif j.startswith(tuple(termbalout)) == True:
                            terminalcompconnect[row][column] = -1
                            column = column + 1
                        else:
                            terminalcompconnect[row][column] = 0
                            column = column + 1
                    else: 
                        column = column + 1
                row = row + 1

            i = 0
            for rows in terminalcompconnect:
                if (np.sum(rows**2) > 1 and 1 in terminalcompconnect[i,:] and 
                        -1 in terminalcompconnect[i,:]):
                    terminalcompconnect[i]
                else:
                    terminalcompconnect[i][:] = 'NaN'
                i = i+1

            dfcompconnect = pd.DataFrame(terminalcompconnect, 
                columns = all_edges)
            dfcompconnect = dfcompconnect.dropna()

            connect_comp = connect_comp.append(dfcompconnect, 
                ignore_index = True)
        
        #-----------------------------------------------------------------------
        # Build component summation connectivity to equate to total mass flow 
        # of each stream
        #-----------------------------------------------------------------------
        totalsum = np.zeros((int(numedge),int(numalledge)))
        
        column = 0
        row = 0
        
        for i in edges:
            for j in all_edges:
                if i in j:
                    totalsum[row][column] = 1
                    column = column + 1
                else: 
                    column = column + 1
            row = row + 1
            column = 0

        #-----------------------------------------------------------------------
        # Remove row corresponding to mass only nodes:
        #-----------------------------------------------------------------------
        i = 0
        for rows in totalsum:
            if np.sum(rows) > 0:
                totalsum[i]
            else:
                totalsum[i][:] = 'NaN'
            i = i+1

        dftotalsum = pd.DataFrame(totalsum, columns = all_edges)
        dftotalsum = dftotalsum.dropna()

        #-----------------------------------------------------------------------
        # Build connectivity for the reaction pathway (if necessary)
        #-----------------------------------------------------------------------
        #if reaction_indicator == 1:
            #Enter Reaction Pathway Connectivity Generator Here

        total_connect = connect_comp.append(dftotalsum, ignore_index = True)

    return total_connect

def unmeasured_removal(A_mat, edges, unmeasured, datain, variancein, b):
    len_unmeasured = len(unmeasured)
    
    if len_unmeasured == 0:
        Reduced_Amat = A_mat.to_numpy()
        Reduced_data = datain.to_numpy()
        Reduced_variance = variancein.to_numpy()
        measured_edges = edges
        measured_b = b

    else:
        df_A = pd.DataFrame(A_mat, columns = edges)

        # Calculate the Q and R matrices that reduce the full A and b matrices 
        # to the measured-only A and b matrices
        unmeasured_A = df_A[unmeasured]
        unmeasured_A = unmeasured_A.to_numpy()

        q, r = np.linalg.qr(unmeasured_A, mode = 'complete')
        P = q[:,len_unmeasured:]

        # Calculate the reduced A matrix
        measured_A = np.dot(np.transpose(P),A_mat)
        measured_A = pd.DataFrame(measured_A, columns = edges)

        Reduced_A = measured_A.drop(unmeasured, axis=1)
        Reduced_Amat = Reduced_A.to_numpy()

        # Calculate the reduced B matrix
        measured_b = np.matmul(np.transpose(P),b)

        #Remove the rows from the measurement and variance arrays
        measurement_index = ([df_A.columns.get_loc(c) for c in unmeasured if c 
            in df_A])
        measured_edges = edges.drop(measurement_index, axis=0)

        Reduced_datain = datain.drop(unmeasured, axis=0)
        Reduced_varin = variancein.drop(unmeasured, axis=0)
    
        Reduced_data = Reduced_datain.to_numpy()  
        Reduced_variance = Reduced_varin.to_numpy()

    return Reduced_Amat, Reduced_data, Reduced_variance, measured_edges, measured_b

def reconciliation(A_mat, datain, variancein, measured_edges, b):    
    numdata = len(datain)
    
    # Input A Matrix is the Reduced Connectivty Matrix C for measured variables

    A_mat_reduced = np.matrix(A_mat) 

    # Input data and variance are only for the measured variables

    V = np.multiply(np.multiply(datain,variancein)**2,np.eye(numdata))

    VAT = np.dot(V,np.transpose(A_mat_reduced))

    AVAT = np.dot(A_mat_reduced,np.dot(V,np.transpose(A_mat_reduced)))
    AVAT_inverse = np.linalg.inv(AVAT)

    PreFactor = np.matmul(VAT, AVAT_inverse)
    Matrix_Results = np.dot(PreFactor,A_mat_reduced)
    Aug_Matrix_Results = np.eye(numdata) - Matrix_Results

    # Matrix Solution is y_rec = (I - [VAT]*[(AVAT)^-1]*A)*y - [VAT]*[(AVAT)^-1]*d]

    Balance_Results = np.transpose(np.matmul(Aug_Matrix_Results,datain))

    Constant_Results = np.matmul(PreFactor,b)

    reconciled = Balance_Results + Constant_Results

    rec_trans = np.transpose(reconciled)

    reconciled_DF = pd.DataFrame(rec_trans, columns = measured_edges)

    return reconciled, reconciled_DF, V

def Calc_Unmeasured(A_mat, reconciled_meas, edges, unmeasured, b):
    # Get measured A matrix
    df_A = pd.DataFrame(A_mat, columns = edges)

    df_A_meas = df_A.drop(columns = unmeasured)
    A_meas = df_A_meas.to_numpy()

    # Get unmeasured A matrix
    df_A_unmeas = df_A[unmeasured]
    A_unmeas = df_A_unmeas.to_numpy()

    b = pd.DataFrame(b)
    b = b.to_numpy()

    # Calculate unmeasured variables
    RHS = -1*np.matmul(A_meas,reconciled_meas) + b
    unmeasured_values = np.linalg.lstsq(A_unmeas, RHS, rcond = None)
    unmeasured_values = unmeasured_values[0]

    unmeasured_values = np.where(unmeasured_values < 1e-10, 1e-10, 
        unmeasured_values)

    unmeasured_values = pd.DataFrame(np.transpose(unmeasured_values), 
        columns = unmeasured)

    return unmeasured_values

def GED_Analysis(A_mat, Var_Mat, Measured_Rec, Measured_AsIs, new_unmeasured, 
    measured_edges, b):

    Balance_Results = np.matmul(A_mat, Measured_Rec) - b.T

    Balance_Results = Balance_Results[0][:]

    Bal_Var = np.matmul(A_mat,np.matmul(Var_Mat,np.transpose(A_mat)))
    Bal_Var_Inv = np.linalg.inv(Bal_Var)

    score = np.matmul(Balance_Results.T,np.matmul(Bal_Var_Inv,Balance_Results))

    dof = len(Measured_Rec)
    chi2_stat = st.stats.distributions.chi2.ppf(0.95, df = dof)

    if abs(score) > chi2_stat:
        countGED = 1
        print('Gross Error Detected')    
    else:
        countGED = 0
        print('Score =', abs(score),'Threshold =', chi2_stat)
        print('No GED Detected')
            
    if countGED == 1:
        print('Score =', abs(score),'Threshold =', chi2_stat)
        try:
            delta = abs(np.transpose(Measured_AsIs) - Measured_Rec)
            #print(delta)

            W1 = np.matmul(A_mat,Var_Mat)
            W2 = np.matmul(np.linalg.inv(Bal_Var),W1)
            W3 = np.matmul(np.transpose(A_mat),W2)
            W = np.matmul(Var_Mat,W3)

            W_diag = np.diag(np.diag(W))

            cond = np.linalg.cond(W_diag)
            print(cond)

            #Error is in the inversion of W_diag
            W_inv = abs(np.linalg.inv(W_diag))

            Z_score = np.matmul(np.sqrt(W_inv),np.transpose(delta))
            measurement_score = (Measured_AsIs, Z_score)

            i = 0
            for meas in measurement_score[0]:
                if meas < 1e-5:
                    measurement_score[1][i] = 0
                i = i+1

            Zscore_df = pd.DataFrame(Z_score, index = measured_edges)
            
            Z_stat = st.norm.ppf(0.95)

            Zscore_filtered = Zscore_df[Zscore_df[0] > Z_stat]

            label = Zscore_filtered.idxmax()
            
            new_unmeasured = new_unmeasured.append(label, ignore_index = True)

        except Exception as Reason:
            print(Reason)
            print('No further gross errors to remove')
            countGED = 0

    return countGED, new_unmeasured

def Repair(reconciledval, calculatedval, edges):

    Results = pd.concat([reconciledval,calculatedval], axis=1, sort=False)

    Results = Results[edges]

    Results = Results.transpose()

    return Results


def run_DR_GED(file_name):
    #---------------------------------------------------------------------------
    # Extract data from Excel file
    #---------------------------------------------------------------------------
    with open(file_name, 'r') as file:
        json_input = file.read()
    job_id, model_id, calculation_type, map, nodes, edges, all_edges_mass, measured_mass, massvariance, unmeasured, measured_comp, compvariance, unmeasured_comp, all_edges_comp, comp_indicator, interunit_indicator, terminal_indicator, reaction_indicator, total, compmeas, termbalin, termbalout = read_data(json_input)
    
    original_unmeasured_mass = unmeasured
    original_unmeasured_comp = unmeasured_comp
    
    measured_mass_df = pd.DataFrame(measured_mass, index = all_edges_mass)
    compvariance_df = pd.DataFrame(massvariance, index = all_edges_mass)
    
    measured_comp_df = pd.DataFrame(measured_comp, index = all_edges_comp)
    compvariance_df = pd.DataFrame(compvariance, index = all_edges_comp)
    
    #---------------------------------------------------------------------------
    # Build connectivity matrices for mass balance and composition balance 
    # (if necessary)
    #---------------------------------------------------------------------------
    A_matrix_mass = connectivity(nodes, edges, all_edges_mass, 0, 0, 0, 0, 0, [], [])   

    #---------------------------------------------------------------------------
    # Perform Overall Mass Balance Reconciliation
    #---------------------------------------------------------------------------
    GEDIndicator = 1
    print('---------------------------------------------')
    print('START MASS BALANCE RECONCILIATION')
    
    while GEDIndicator == 1:
        print('---------------------------------------------')
        #Remove unmeasured variables from the A matrix
        b = np.zeros((len(A_matrix_mass.to_numpy()[:,1]),1))
        A_matrix_measured, Data_Measured, Variance_Measured, measured_edges, b_measured = unmeasured_removal(A_matrix_mass, all_edges_mass, unmeasured, measured_mass, massvariance, b)
    
        #Solve the reconciliation problem using the matrix equation solution 
        #(weighted least squares with linear constraints)  
        reconciled, reconciled_DF, Variance_Mat = reconciliation(A_matrix_measured, Data_Measured, Variance_Measured, measured_edges, b_measured)
    
        #Calculate the unmeasured variables
        unmeasured_rec = Calc_Unmeasured(A_matrix_mass, reconciled, all_edges_mass, unmeasured, b)
        
        #Calculate GED Tests
        GEDIndicator, unmeasured = GED_Analysis(A_matrix_measured, Variance_Mat, Data_Measured, reconciled, unmeasured, measured_edges, b_measured)
    
        #Concatenate the reconciled and calculated values and print results to Excel
        rec_data = Repair(reconciled_DF, unmeasured_rec, all_edges_mass)
    
        measured_mass_df = pd.concat([measured_mass_df, rec_data], axis=1, ignore_index=True, join='inner')
    
        if GEDIndicator == 1:
            original_unmeasured_mass = pd.concat([original_unmeasured_mass, unmeasured], axis=1, ignore_index=True)
    
    #---------------------------------------------------------------------------
    # Perform Composition Reconciliation if Necessary
    #---------------------------------------------------------------------------
    if comp_indicator == 1:
        print('---------------------------------------------')
        print('START COMPOSITION RECONCILIATION')
        print('---------------------------------------------')
        A_matrix_comp = connectivity(nodes, edges, all_edges_comp, comp_indicator, interunit_indicator, terminal_indicator, reaction_indicator, total, termbalin, termbalout)
        
        #-----------------------------------------------------------------------
        # Build the original B matrix
        #-----------------------------------------------------------------------
    
        compstream = []
    
        print(compmeas)
    
        for stream in compmeas:
            compstream.append(stream+'_'+'0')
    
        b = measured_mass_df[measured_mass_df.columns[-1]]
        b = b.loc[compstream]
    
        print(b)
    
        b = b.to_numpy()
    
        A_matrix_check = A_matrix_comp.to_numpy()
    
        i = 0
        for rows in A_matrix_check:
            if any(x == -1 for x in rows):
                i = i + 1
    
        b_zero = np.zeros((i,1))
    
        b = np.append(b_zero, b)
    
        b = pd.DataFrame(b)
        b = b.to_numpy()
    
        #-----------------------------------------------------------------------
        # Perform the DR and GED
        #-----------------------------------------------------------------------
    
        GEDIndicator = 1
        numiter = 0
    
        while GEDIndicator == 1:
            #Remove unmeasured variables from the A matrix
            A_matrix_measured, Data_Measured, Variance_Measured, measured_edges, b_measured = unmeasured_removal(A_matrix_comp, all_edges_comp, unmeasured_comp, measured_comp, compvariance, b)

            #Solve the reconciliation problem using the matrix equation solution (weighted least squares with linear constraints)
            reconciled, reconciled_DF, Variance_Mat = reconciliation(A_matrix_measured, Data_Measured, Variance_Measured, measured_edges, b_measured)
    
            #Calculate the unmeasured variables
            unmeasured_rec = Calc_Unmeasured(A_matrix_comp, reconciled, all_edges_comp, unmeasured_comp, b)
    
            #Calculate GED Tests
            GEDIndicator, unmeasured_comp = GED_Analysis(A_matrix_measured, Variance_Mat, Data_Measured, reconciled, unmeasured_comp, measured_edges, b_measured)
    
            #Concatenate the reconciled and calculated values and print results to Excel
            rec_data = Repair(reconciled_DF, unmeasured_rec, all_edges_comp)
    
            measured_comp_df = pd.concat([measured_comp_df, rec_data], axis=1, ignore_index=True, join='inner')
    
            if GEDIndicator == 1:
                original_unmeasured_comp = pd.concat([original_unmeasured_comp, unmeasured_comp], axis=1, ignore_index=True)
    
            numiter = numiter + 1
    
            if numiter > 10:
                break
    
    #---------------------------------------------------------------------------
    # Create dictionary of everything to return
    #---------------------------------------------------------------------------
    output_data_list = []
    input_file=configur.get("SSD_code","Input_Configuration_file")
    wb = openpyxl.load_workbook(input_file)
    sheet = wb.get_sheet_by_name("Data Reconciliation")
    rows=dataframe_to_rows(rec_data)

    for r_id,row in enumerate(rows,6):
        for c_id,value in enumerate(row,9):
            sheet.cell(row=r_id,column=c_id,value=value)
            tm_stmp=datetime.now()
            sheet.cell(row=r_id,column=11,value=tm_stmp)
            
    wb.save(configur.get("SSD_code","Output_Configuration_file"))
    # add reconciled mass to output_data_list
    for index, value in measured_mass_df.iloc[:,-1].items():
        stream_key, comp_index = index.split('_')
        comp_index = int(comp_index)
        for num, stream in map.items():
            if stream['edge'] == stream_key:
                tag_begin = stream['tag_name']
                if tag_begin == "":
                    continue
                if stream['data_model_revision'] == 'D':
                    tag_end_dr = ".FlowMass_UOPPredictionModel"
                    tag_end_ged = ".FlowMass_GEDFlag"
                elif stream['data_model_revision'] == 'F':
                    tag_end_dr = ".FlowMass_Reconciled[SteadyState]"
                    tag_end_ged = ".FlowMassFlagGrossError_Reconciled[SteadyState]"
                elif stream['data_model_revision'] == 'Suncor':
                    tag_end_dr = ".PV_AG"
                    tag_end_ged = ".CL_ECPR"
                tag_dr = tag_begin + tag_end_dr
                output_data = {"tagName" : tag_dr,
                               "value" : value,
                               "outputConfiguration" : {}}
                output_data_list.append(output_data)
                if stream['has_GEDFlag'] == True:
                    tag_ged = tag_begin + tag_end_ged
                    ged_indicator = 0
                    if index in original_unmeasured_mass.values:
                        ged_indicator = 1
                    output_data = {"tagName" : tag_ged,
                                   "value" : ged_indicator,
                                   "outputConfiguration" : {}}
                    output_data_list.append(output_data)
                break
    
    out_timestamp = str(int(datetime.now().timestamp()) * 1000)
    out_timestamp_1 = int(datetime.now().timestamp())
    dict_output = {"JobId" : job_id,
                   "ModelId" : model_id,
                   "CalculationType" : calculation_type,
                   "TimeStamp" : out_timestamp,
                   "Configuration" : {},
                   "OutputDataList" : output_data_list}
    
    json_output = json.dumps(dict_output)
    with open(configur.get("SSD_code","MR_output_JSON_file"), 'w') as file:
        json.dump(dict_output, file, indent = 4)
    with open(configur.get("SSD_code","MR_write_PHD_data_csvFile"),'w',newline='') as outfile:
        writer=csv.writer(outfile)
        writer.writerow(["tagname","timestamp","value"])

        for item in output_data_list:
            new_tag=item['tagName']
            new_value= item['value']
            
            new_timestamp=datetime.utcfromtimestamp(out_timestamp_1).strftime("%Y-%m-%d %H:%M:%S")
            writer.writerow([new_tag,new_timestamp,new_value] )
    return json_output
