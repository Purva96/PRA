import subprocess,sys
import xlrd
import pandas as pd
import time

xlrd.xlsx.ensure_elementtree_imported(False, None)
xlrd.xlsx.Element_has_iter = True

input_file="PDME SSD v3.0-beta6.xlsm"
rb = xlrd.open_workbook(input_file)
sheetNames = rb.sheet_names()

pros= subprocess.Popen(["C:\\Windows\\syswow64\\WindowsPowerShell\\v1.0\\powershell.exe",".\\PHD.PS1"],stdout=sys.stdout)
pros.communicate()

def Merge(dict1,dict2,dict3,dict4):
    res={**dict1,**dict2,**dict3,**dict4}
    return(res)


def json_input(sheet,tags_dict,tags_dict2,tags_dict3):
    
    values_list=sheet.row_values(7)
    odWindowSize=values_list[5]
    odAlpha=values_list[6]
    odWindowPosition=values_list[7]
    IntervalMins=values_list[8]
    noise=values_list[9]
    ssAlpha=values_list[11]
    ssWindowPosition=values_list[12]
                
    Configuration={
        "MODEL_SERVICE_TOKEN": "<Token>",
        "MODEL_SERVICE_ENDPOINT": "<URL>",
        "DO_SSD_THRESHOLD": "0.9",
        "INTERVAL": "30",
        "SAMPLE_DATA_FREQUENCY": "2000",
        "DELAY": "150",
        "OD_window_size":odWindowSize,
        "OD_alpha":odAlpha,
        "OD_window_position":odWindowPosition,
        "interpolated_minute": IntervalMins,
        "noise":noise,
        "SS_alpha":ssAlpha,
        "SS_window_position":ssWindowPosition,      
        
    }    
#     print(Merge(Configuration,tags_dict,tags_dict2,tags_dict3))
    main_config=Merge(Configuration,tags_dict,tags_dict2,tags_dict3)
    
    return main_config
        
timeStamps=[]
values=[]
InputDataList=[]
main_input_dict={}
ssd_dict={}
OutputDataList=[]

def inputDataList(critical_sensor_tag_values):
    pattern="%m-%d-%Y %H:%m:%s"

    data=pd.read_csv("suncorDATA.csv")
    
    
    
    for total_tags in range(0,len(critical_sensor_tag_values)):
        print(total_tags)
        print("Fetching data for ",critical_sensor_tag_values[total_tags])
        for i,j in data.iterrows():            
    #         print(i)
            TagName=i[0]
            if TagName== critical_sensor_tag_values[total_tags]:
                
                if i[1] == "TimeStamp":
                    pass
                else:
                    dates=pd.to_datetime(i[1])
        #             print((dates - pd.Timestamp("1970-01-01")) / pd.Timedelta('1s'))
                    epoch=(dates - pd.Timestamp("1970-01-01")) / pd.Timedelta('1s')
                    timeStamps.append(str(epoch))
        #             print(i[2])
                    values.append(i[2])

                series_8=pd.Series(timeStamps)
            #     print(series_8)
                series_9=pd.Series(values)

                timeStampsToValueMap={"timestamp":series_8,"values":series_9}
                dframe4= pd.DataFrame(timeStampsToValueMap)
                tags_dict4=dframe4.set_index('timestamp')["values"].to_dict()
            else:
                pass
        
        main_input_dict={
            "tagName": critical_sensor_tag_values[total_tags],
            "dataScienceTagName": "null",
            "value": "null",
            "timeStampsToValueMap":tags_dict4,
            "tagConfiguration": "null"
        }
        main_output_dict={
            "tagName": critical_sensor_tag_values[total_tags].split(".")[0]+".SSD_ST",
            "dataScienceTagName": "null",
            "value": "null",
            "outputConfiguration": "null"
        }
        
        # print(main_input_dict)
        InputDataList.append(main_input_dict)
        OutputDataList.append(main_output_dict)
#     print(InputDataList)
        
    ssd_dict={
            "tagName": "ProcessUnit.SSD1_ST",
            "dataScienceTagName": "null",
            "value": "null",
            "outputConfiguration": "null"
        }    
    OutputDataList.append(ssd_dict)    
    
    return InputDataList,OutputDataList
#     print(tags_dict4)

def final_json_file(main_config,InputDataList,OutputDataList):
    Final_dict={
        "JobId": "8886dde9-c45c-451f-9bb4-226514bcd57f",
        "ModelId": "model-cps-dev-tester",
        "CalculationType": "SSD",
        "Configuration":main_config,
        "InputDataList":InputDataList,
        "OutputDataList": OutputDataList
    }
    return Final_dict

critical_sensor_tag_values=[]
critical_sensor_tag_keys=[]
critical_tags_window_size_keys=[]
critical_tags_window_size_values=[]
critical_tags_likelihood_keys=[]
critical_tags_liklihood_values=[]
tags_dict4= {}
a=b=c=1

for name in sheetNames:
    if name== "Data Extraction":
        sheet1= rb.sheet_by_name(name)
        rows=sheet1.nrows
        for i in range(rows):
            if sheet1.cell_value(i,4) == 'x':
                critical_sensor_tag_values.append(sheet1.cell_value(i,5))
                series_1=pd.Series(critical_sensor_tag_values)
                critical_sensor_tag_keys.append("CRITICAL_TAG_%d_NAME"%(a))
                series_2=pd.Series(critical_sensor_tag_keys)
                a+=1
        #create a dataframe        
        Data={"sensor_tag_names":series_2,"tags":series_1}
        dframe=pd.DataFrame(Data)      
        
        #convert dataframe to dictionary
        tags_dict=dframe.set_index('sensor_tag_names')['tags'].to_dict()
#         print(tags_dict)

        
    if name=="Steady State Detection":
        sheet=rb.sheet_by_name(name)
        for key,value in tags_dict.items():
            for i in range(sheet.nrows):
                      
                if value == sheet.cell_value(i,4):
                    critical_tags_window_size_values.append(sheet.cell_value(i,10))
                    series_4=pd.Series(critical_tags_window_size_values)
                    critical_tags_window_size_keys.append("CRITICAL_TAG_%d_WINODW_SIZE"%(b))
                    series_3=pd.Series(critical_tags_window_size_keys)
                    b+=1
                    critical_tags_liklihood_values.append(sheet.cell_value(i,13)*100)
                    series_5=pd.Series(critical_tags_liklihood_values)
                    critical_tags_likelihood_keys.append("CRITICAL_TAG_%d_LIKELIHOOD_REQ"%(c))
                    series_6=pd.Series(critical_tags_likelihood_keys)        
                    c+=1     
                    
                    
         
        Data2={"window_size_tag_names":series_3,"window_size_tag_values":series_4}
        Data3={"likelihood_tag_names":series_6,"likelihood_values":series_5}
        dframe2=pd.DataFrame(Data2)
        #convert dataframe to dictionary
        tags_dict2=dframe2.set_index('window_size_tag_names')["window_size_tag_values"].to_dict()
        dframe3=pd.DataFrame(Data3)
        tags_dict3=dframe3.set_index('likelihood_tag_names')["likelihood_values"].to_dict()
        
#         print(dframe2)
        
#         tags_dict2=dframe.set_index('window_size_tag_names').to_dict()
#         print(tags_dict2)
#         print(tags_dict3)
        
main_config=json_input(sheet,tags_dict,tags_dict2,tags_dict3)
# print(main_config) 

# TagName,tags_dict4  =
InputDataList,OutputDataList=inputDataList(critical_sensor_tag_values)
# print(TagName)

Final_dict=final_json_file(main_config,InputDataList,OutputDataList)

import json

json_object=json.dumps(Final_dict,indent=4)

with open("inputJSONfile.json","w") as outfile:
    outfile.write(json_object)
