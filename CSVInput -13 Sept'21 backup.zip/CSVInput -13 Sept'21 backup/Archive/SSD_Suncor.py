import json
import re
from datetime import datetime 
from tagclass import SteadyStateTag
from commonclass import CommonSteadyStates
import csv

def convert_json(json_input):
    # Parse input JSON data from input
    
    input = json.loads(json_input)
    
    job_id = input['JobId']
    model_id = input['ModelId']
    calculation_type = input['CalculationType']
    configuration = input['Configuration']
    input_data_list = input['InputDataList']
    output_data_list = input['OutputDataList']

    #Get global SSD parameters:
    global_input = {
        "OD_window_size" : 11,
        "OD_alpha" : 0.05,
        "OD_window_position" : 0.5, #replaced by Forge config?
        "interpolated_minute" : 1, #replaced by Forge config?
        "noise" : 0.01,
        "SS_alpha" : 0.05,
        "SS_window_position" : 0.5, #replaced by Forge config?
        "SS_window_size" : [],
        "likelihood_requirement" : []
        }

    #create list of sensor tags
    #Get Sensor Tag Names
    sensor_tags = []
    output_tags = []

    for data_sets in input_data_list:
        sensor_tags.append(data_sets['tagName'])

    for tags in output_data_list:
        output_tags.append(tags['tagName'])

    input_rawdata = {}
    #Create new list of dictionaries with inputs and data for each tag
    for tag in sensor_tags:
        input_rawdata[tag] = {}
        input_rawdata[tag]['sensor_input'] = global_input.copy()

        for key, value in configuration.items(): 
            if tag == value:         
                tag_key_number = re.findall(r'\d+', key)
            
                input_rawdata[tag]['sensor_input']["SS_window_size"] = int(configuration['CRITICAL_TAG_'+tag_key_number[0]+"_WINODW_SIZE"]) #change to parse by tag name in config
                input_rawdata[tag]['sensor_input']["likelihood_requirement"] = int(configuration['CRITICAL_TAG_'+tag_key_number[0]+"_LIKELIHOOD_REQ"])/100 #change to parse by tag name in config

        for inputs in input_data_list:
            if inputs["tagName"] == tag:
                #input_rawdata[tag]["tagCheck"] = tag
                input_rawdata[tag]["data"] = inputs["timeStampsToValueMap"]

    return job_id, model_id, calculation_type, configuration, sensor_tags, input_rawdata, output_tags


def get_steady_states(tag_name, raw_data):
    """Get steady state data points for a single tag."""

    # get raw sensor data from the local cache database
    inputs = raw_data[tag_name]["sensor_input"]
    times = [float(i) for i in raw_data[tag_name]["data"].keys()]
    data = [float(i) for i in raw_data[tag_name]["data"].values()]
    
    # get input parameters
    #name = inputs["name"]
    name = tag_name
    OD_window_size = inputs["OD_window_size"]
    OD_alpha = inputs["OD_alpha"]
    OD_window_position = inputs["OD_window_position"]
    interpolated_minute = inputs["interpolated_minute"]
    noise = inputs["noise"]
    SS_window_size = inputs["SS_window_size"]
    SS_alpha = inputs["SS_alpha"]
    SS_window_position = inputs["SS_window_position"]
    likelihood_requirement = inputs["likelihood_requirement"]
    
    # run steady state analysis
    tag = SteadyStateTag(times, data, name)
    tag.remove_outliers(OD_window_size, OD_alpha, OD_window_position)
    tag.change_frequency(interpolated_minute, noise)
    tag.get_SS_likelihood(SS_window_size, SS_alpha, SS_window_position)
    tag.get_SS_signal(likelihood_requirement)
    tag.get_SS_time_ranges()
    
    return tag


# def get_all_steady_states_parallel(sensor_tags, raw_data):
#     """Get steady state data points for all tags in parallel."""
    
#     # get all tag data
#     pool = mp.Pool(mp.cpu_count())
#     all_tags = pool.starmap(get_steady_states, [(x, y) 
#             for x, y in zip(sensor_tags, raw_data)])
#     pool.close()
#     pool.join()
    
#     return all_tags


def get_all_steady_states_series(sensor_tags, raw_data):
    """Get steady state data points for all tags in series."""
    
    all_tags = []
    for i in range(len(sensor_tags)):
        print("Processing Tag: " + sensor_tags[i])
        tag = get_steady_states(sensor_tags[i], raw_data)
        all_tags.append(tag)
    
    return all_tags


def get_common_steady_states(all_tags, lab_tags, min_SS_length_hour, 
    min_number_labs):
    """Get common steady states across all tags."""

    common = CommonSteadyStates(all_tags)
    common.get_steady_lengths()
    #common.get_labs_per_steady_range(lab_tags)
    #common.get_passing_steady_ranges(min_SS_length_hour, min_number_labs)

    return common


def package_results(job_id, model_id, calculation_type, all_tags, common, output_tags):

    json_output = {}

    json_output["JobId"] = job_id
    json_output["ModelId"] = model_id
    json_output["CalculationType"] = calculation_type
    json_output["Configuration"] = {}

    with open("Output.csv","a") as file:
        writer= csv.writer(file)
        writer.writerow(["tagname","timestamp","value"])

        #---------------------------------------------------------------------#
        # Build Output Data Set for Each Process Tag
        #---------------------------------------------------------------------#

        i = 0
        Results = []
        for tags in all_tags:

            tag_results = {}
            tag_results["tagName"] = output_tags[i]

            tag_results["output_data"] = {}

            for j in range(len(tags.final_times)):
                tag_results["output_data"][tags.final_times[j]] = tags.signal[j]

            tag_results["outputConfiguration"] = {}

            Results.append(tag_results)
            i = i + 1

        #---------------------------------------------------------------------#
        # Build Output Data Set for Unit Level Steady State
        #---------------------------------------------------------------------#

        unit_results = {}
        unit_results["tagName"] = output_tags[i]
        unit_results["output_data"] = {}

        for times in all_tags[0].final_times:
            for low, high in common.steady_ranges:
                if low <= times <= high:
                    unit_results["output_data"][times] = 1
                else:
                    unit_results["output_data"][times] = 0

                timestamp=datetime.utcfromtimestamp(times).strftime("%Y-%m-%d %H:%M:%S")
                
                writer.writerow([tag_results["tagName"],timestamp,unit_results["output_data"][times]])
        Results.append(unit_results)

        json_output["OutputDataList"] = Results

    return json_output


def runSSD(json_input):
    job_id, model_id, calculation_type, configuration, sensor_tags, input_rawdata, output_tags = convert_json(json_input)

    #mp.freeze_support()
    #all_tags = get_all_steady_states_parallel(sensor_tags, input_rawdata)

    lab_tags = []
    min_SS_length_hour = 2
    min_number_labs = 0

    all_tags = get_all_steady_states_series(sensor_tags, input_rawdata)

    print('Getting Common Steady States')

    common = get_common_steady_states(all_tags, lab_tags, min_SS_length_hour, 
            min_number_labs)

    json_output = package_results(job_id, model_id, calculation_type, all_tags, common, output_tags)

    return json_output, all_tags, common