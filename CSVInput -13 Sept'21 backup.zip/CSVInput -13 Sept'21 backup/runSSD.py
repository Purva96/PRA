import sqlite3
from sqlite3 import Error
import json
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates 
from buildjson import *
from SSD_Suncor import *
from configparser import ConfigParser


configur = ConfigParser()
print (configur.read('config.ini'))
#---------------------------------------------------------------------#
# User Defined Database, Critical Tags as Inputs
#---------------------------------------------------------------------#

def SSD_func():
	
	build_json = 0
	choose_plot_tag = 0
	plot_data_length = 1 #as percentage of number of data points, i.e. 0.5 = 50%

	#---------------------------------------------------------------------#
	# Build JSON file for SSD from local cache database
	# or call available JSON from Forge
	#---------------------------------------------------------------------#

	if build_json == 1:
	    database = "DC.sqlite"
	    file_name = "SSD-input-Offline.json"
	    JSON = read_data(database, SSD_Inputs_KPPC)  
	else:
	    file_name = configur.get("SSD_code","SSD_input_JSON_file")

	# Run SSD code by calling pseudo-API and make JSON output text file

	with open(file_name, 'r') as file:
	    json_input = file.read()

	json_output, all_tags, common,otag_value = runSSD(json_input,0)
	#json_output = runSSD(json_input)

	# Print Output JSON to File

	with open(configur.get("SSD_code","SSD_output_JSON_file"), "w") as outfile:  
	    json.dump(json_output, outfile, indent = 4)

	# Print Common Times to Terminal
	common_times = [(datetime.utcfromtimestamp(i).strftime('%m-%d-%Y %H:%M'),
	    datetime.utcfromtimestamp(j).strftime('%m-%d-%Y %H:%M'))  for i,j in common.steady_ranges]

	print(*common.steady_ranges, sep = '\n')

	print(*common_times, sep = "\n")
    

	#---------------------------------------------------------------------#
	# Example Plot of Selected Results
	#---------------------------------------------------------------------#

	#data_length = int(round(plot_data_length*len(all_tags[choose_plot_tag].final_times)))

	#time = [datetime.utcfromtimestamp(i).strftime('%m-%d-%Y %H:%M') for i in all_tags[choose_plot_tag].final_times]

	#t = time[:data_length]

	#data1 = all_tags[choose_plot_tag].final_data[:data_length]
	#data2 = all_tags[choose_plot_tag].signal[:data_length]

	#fig, ax1 = plt.subplots()

	#color = 'tab:red'
	#ax1.set_xlabel('time (UTC)')
	#ax1.set_ylabel('Process Data for: ' + all_tags[choose_plot_tag].name, color=color)
	#ax1.plot(t, data1, color=color)
	#ax1.tick_params(axis='y', labelcolor=color)

	# Define the date format
	#ax1.xaxis.set_major_locator(mdates.DayLocator(interval=1800))
	#fig.autofmt_xdate()

	#ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis
	#ax2.xaxis.set_major_locator(mdates.DayLocator(interval=1800))


	#color = 'tab:blue'
	#ax2.set_ylabel('SSD Signal', color=color)  # we already handled the x-label with ax1
	#ax2.plot(t, data2, color=color)
	#ax2.tick_params(axis='y', labelcolor=color)

	#fig.tight_layout()  # otherwise the right y-label is slightly clipped
	#plt.show()
    
	return otag_value
