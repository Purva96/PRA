import sys
import json
import multiprocessing as mp
from datetime import datetime
from tagclass import SteadyStateTag
from commonclass import CommonSteadyStates
import database as db
from writedata import write_SS_results, write_SS_summary

def steady_state_detection(args):
    """Set up Steady State Detection."""
    
    try:
        in_source = args[0]
    except(IndexError):
        sys.exit("Error! No input data source specified.\n"
                "The first argument after 'SSD' should be one of:\n"
                "'test' for testing purposes\n"
                "'file' for steady state detection from file")
    
    if in_source == 'test':
        sensor_tags = ['pi_12134_01.pv_ag',
                       'ti_12124_01.pv_ag',
                       'fi_12107_01_b.pv_ag',
                       'ti_12115_01_a.pv_ag',
                       'ti_12107_01.pv_ag']
        lab_tags = ['sn_12107_01_pmd_000.pv_ag',
                    'sn_12107_01_pmd_005.pv_ag',
                    'sn_12107_01_pmd_010.pv_ag',
                    'sn_12107_01_pmd_020.pv_ag',
                    'sn_12107_01_pmd_050.pv_ag',
                    'sn_12107_01_pmd_090.pv_ag',
                    'sn_12107_01_pmd_095.pv_ag',
                    'sn_12107_01_pmd_100.pv_ag']
        sensor_input = {
            "name" : "",
            "OD_window_size" : 11,
            "OD_alpha" : 0.05,
            "OD_window_position" : 0.5,
            "interpolated_minute" : 1,
            "noise" : 0.01,
            "SS_window_size" : 121,
            "SS_alpha" : 0.05,
            "SS_window_position" : 0.5,
            "likelihood_requirement" : 0.70
        }
        sensor_inputs = [sensor_input] * len(sensor_tags)
        for i in range(len(sensor_inputs)):
            sensor_inputs[i]["name"] = sensor_tags[i]
        start_time = datetime(2020, 1, 2, 0, 0).timestamp()
        end_time = datetime(2020, 1, 9, 0, 0).timestamp()
        min_SS_length_hour = 0
        min_number_labs = 0
    elif in_source == 'file':
        sensor_tags = json.loads(args[1])
        lab_tags = json.loads(args[2])
        sensor_inputs = json.loads(args[3])
        start_time = int(args[4])
        end_time = int(args[5])
        min_SS_length_hour = int(args[6])
        min_number_labs = int(args[7])
    else:
        sys.exit("Error! No input data source specified.\n"
                "The first argument after 'SSD' should be one of:\n"
                "'test' for testing purposes\n"
                "'file' for steady state detection from file")
    
    all_tags = get_all_steady_states_parallel(sensor_tags, start_time, 
            end_time, sensor_inputs)
    db.insert_steady_data(all_tags)
    common = get_common_steady_states(all_tags, lab_tags, min_SS_length_hour, 
            min_number_labs)
    #db.insert_steady_states(common.steady_ranges)
    
    if in_source == 'test':
        print("Time ranges at Steady State:")
        for c in common.steady_ranges:
            print(datetime.fromtimestamp(c[0]), "to", 
                    datetime.fromtimestamp(c[1]))
    else:
        write_SS_results(all_tags)
        write_SS_summary(common)


def get_steady_states(tag_name, start_time, end_time, inputs):
    """Get steady state data points for a single tag."""
    
    # get raw sensor data from the local cache database
    raw_data, tag_type = db.select_raw_data(tag_name, start_time, end_time, 0)
    times = [x[0] for x in raw_data]
    data = [x[1] for x in raw_data]
    
    # get input parameters
    name = inputs["name"]
    OD_window_size = inputs["OD_window_size"]
    OD_alpha = inputs["OD_alpha"]
    OD_window_position = inputs["OD_window_position"]
    interpolated_minute = inputs["interpolated_minute"]
    noise = inputs["noise"]
    SS_window_size = inputs["SS_window_size"]
    SS_alpha = inputs["SS_alpha"]
    SS_window_position = inputs["SS_window_position"]
    likelihood_requirement = inputs["likelihood_requirement"]
    
    # run steady state analysis
    tag = SteadyStateTag(times, data, name)
    tag.remove_outliers(OD_window_size, OD_alpha, OD_window_position)
    tag.change_frequency(interpolated_minute, noise)
    tag.get_SS_likelihood(SS_window_size, SS_alpha, SS_window_position)
    tag.get_SS_signal(likelihood_requirement)
    tag.get_SS_time_ranges()
    
    return tag


def get_all_steady_states_series(sensor_tags, start_time, end_time, 
    sensor_inputs):
    """Get steady state data points for all tags in series."""
    
    all_tags = []
    for i in range(len(sensor_tags)):
        tag = get_steady_states(sensor_tags[i], start_time, end_time, 
            sensor_inputs[i])
        all_tags.append(tag)
    
    return all_tags


def get_all_steady_states_parallel(sensor_tags, start_time, end_time, 
    sensor_inputs):
    """Get steady state data points for all tags in parallel."""
    
    # pre-check to make sure each tag is in the database
    for tag in sensor_tags:
        check = db.select_raw_data(tag, start_time, end_time, 0)
    
    # get all tag data
    pool = mp.Pool(mp.cpu_count())
    all_tags = pool.starmap(get_steady_states, [(x, start_time, end_time, y) 
            for x, y in zip(sensor_tags, sensor_inputs)])
    pool.close()
    pool.join()
    
    return all_tags


def get_common_steady_states(all_tags, lab_tags, min_SS_length_hour, 
    min_number_labs):
    """Get common steady states across all tags."""
    
    common = CommonSteadyStates(all_tags)
    common.get_steady_lengths()
    common.get_labs_per_steady_range(lab_tags)
    #common.get_passing_steady_ranges(min_SS_length_hour, min_number_labs)
    
    return common


