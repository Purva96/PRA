#import database as db

class CommonSteadyStates:
    """Class containing methods used for identifying common steady states.
    
    Inputs:
    
    all_tags : list of SteadyStateTags
        list of items in SteadyStateTag class
    """

    def __init__(self, all_tags):
        self.all_tags = all_tags
        
        all_steady_ranges = []
        for tag in all_tags:
            all_steady_ranges.append(tag.steady_ranges)
        if [] in all_steady_ranges:
            self.steady_ranges = []
            return
        
        all_starts = [x[0] for y in all_steady_ranges for x in y]
        all_ends = [x[1] for y in all_steady_ranges for x in y]
        first_start_time = max([x[0][0] for x in all_steady_ranges])
        last_end_time = min([x[-1][1] for x in all_steady_ranges])
        
        common_steady_ranges = []
        start_time = first_start_time
        while 1:
            # check if start time is in a steady range for all tags
            for steady_ranges in all_steady_ranges:
                for tup in steady_ranges:
                    if tup[0] <= start_time <= tup[1]:
                        in_range = True
                        break
                    if start_time < tup[0]:
                        in_range = False
                        break
                    in_range = False
                if in_range == False: break
            
            if in_range == True:
                # find earliest end time after the start time
                possible_ends = []
                for end in all_ends:
                    if end >= start_time:
                        possible_ends.append(end)
                end_time = min(possible_ends)
                all_ends = possible_ends
                common_steady_ranges.append((start_time, end_time))
                if end_time == last_end_time : break
            
            # find next start time
            possible_starts = []
            for start in all_starts:
                if start > start_time:
                    possible_starts.append(start)
            if possible_starts == []: break
            start_time = min(possible_starts)
            if start_time > last_end_time: break
            all_starts = possible_starts
        
        self.steady_ranges = common_steady_ranges


    def get_steady_lengths(self):
        steady_ranges = self.steady_ranges
        steady_lengths = []
        for start, end in steady_ranges:
            steady_lengths.append((end - start) / 3600)
        
        self.steady_lengths = steady_lengths


    # def get_labs_per_steady_range(self, lab_tags):
    #     steady_ranges = self.steady_ranges
        
    #     labs_per_steady_range = []
    #     for start, end in steady_ranges:
    #         tag_count = 0
    #         for tag in lab_tags:
    #             raw_data, tag_type = db.select_raw_data(tag, start, end, 1)
    #             if len(raw_data) != 0:
    #                 tag_count = tag_count + 1
    #         labs_per_steady_range.append(tag_count)
        
    #     self.labs_per_steady_range = labs_per_steady_range


    # def get_passing_steady_ranges(self, min_SS_length_hour, min_number_labs):
    #     min_SS_length = min_SS_length_hour
    #     steady_ranges = self.steady_ranges
    #     steady_lengths = self.steady_lengths
    #     lab_counts = self.labs_per_steady_range
        
    #     passing_steady_ranges = []
    #     for steady_range, steady_length, lab_count in zip(steady_ranges, 
    #             steady_lengths, lab_counts):
    #         if steady_length >= min_SS_length and lab_count >= min_number_labs:
    #             passing_steady_ranges.append(steady_range)
        
    #     self.passing_steady_ranges = passing_steady_ranges


