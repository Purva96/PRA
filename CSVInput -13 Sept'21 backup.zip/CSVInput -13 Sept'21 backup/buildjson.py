import sqlite3
from sqlite3 import Error
import json
from collections import OrderedDict

def create_connection(db_file):
    """ create a database connection to the SQLite database
        specified by the db_file
    :param db_file: database file
    :return: Connection object or None
    """
    conn = None
    try:
        conn = sqlite3.connect(db_file)
        print('Connection Successful')
    except Error as e:
        print(e)

    return conn


def select_tag_data(conn, tag):
    """
    Query Data by CPS Tag Name
    :param conn: the Connection object
    :param tag:
    :return:
    """
    c = conn.cursor()
    c.execute('SELECT time, data FROM RawData INNER JOIN Tag '
        'INNER JOIN Timestamp WHERE RawData.tag_id = Tag.id AND '
        'RawData.timestamp_id = Timestamp.id AND name=?', (tag,))

    data = c.fetchall()

    return data


def read_data(database, SSD_Inputs):
    JSON = {"JobId" : "8886dde9-c45c-451f-9bb4-226514bcd57f",
                "ModelId" : "model-cps-dev-tester",
                "CalculationType" : "SSD"}

    Configuration = {"MODEL_SERVICE_TOKEN": "<Token>",
        "MODEL_SERVICE_ENDPOINT": "<URL>",
        "DO_SSD_THRESHOLD": "0.9",
        "INTERVAL": "15",
        "SAMPLE_DATA_FREQUENCY": "300",
        "DELAY": "150",
        "OD_window_size" : 11,
        "OD_alpha" : 0.05,
        "OD_window_position" : 0.5,
        "interpolated_minute" : 1,
        "noise" : 0.0001,
        "SS_alpha" : 0.05,
        "SS_window_position" : 0.5}

    #---------------------------------------------------------------------#
    # Create a database connection
    #---------------------------------------------------------------------#

    conn = create_connection(database)

    CPS_OutputTag = []
    input_data = []
    output_data = []

    #---------------------------------------------------------------------#
    # Build Input Data Definition for JSON File
    #---------------------------------------------------------------------#
    i = 1

    for inputs in SSD_Inputs:
        #Get Configuration Dictionary
        Configuration["CRITICAL_TAG_"+str(i)+"_NAME"] = inputs[0]
        Configuration["CRITICAL_TAG_"+str(i)+"_WINODW_SIZE"] = inputs[1]
        Configuration["CRITICAL_TAG_"+str(i)+"_LIKELIHOOD_REQ"] = inputs[2]
        i = i + 1

        # Build Input Tag Data Dictionaries
        with conn:
            #print("Gathering Data for ", tag)
            data = select_tag_data(conn, inputs[0])

        data_dict = dict(data)

        tag_data = {"tagName": inputs[0], "dataScienceTagName": "null", \
                    "value" : "null", "timeStampsToValueMap" : data_dict, \
                    "tagConfiguration" : "null"} 

        input_data.append(tag_data)

        #Get OutputDataList Dictionary
        asset = inputs[0].split(".")
        CPS_OutputTag.append(asset[0]+".SSD1_ST")

    conn.close()

    #---------------------------------------------------------------------#
    # Build Input Data Definition for JSON File
    #---------------------------------------------------------------------#

    for inputs in SSD_Inputs:
        outputs = {"tagName": inputs[0], "dataScienceTagName": "null", \
                "value" : "null", "outputConfiguration" : "null"} 

        output_data.append(outputs)

    unit_output = {"tagName": "ProcessUnit.SSD1_ST", "dataScienceTagName": "null", \
                "value" : "null", "outputConfiguration" : "null"} 

    output_data.append(unit_output)

    JSON["Configuration"] = Configuration
    JSON["InputDataList"] = input_data
    JSON["OutputDataList"] = output_data

    with open("SSD-input-Offline.json", "w") as outfile:  
        json.dump(JSON, outfile, indent = 4)

    return JSON