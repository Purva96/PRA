import xlrd
import pandas as pd
import time
import subprocess,sys
from DataRecon_MB_CB import *
from read_MR_tags import *
from csv import *
from configparser import ConfigParser


configur = ConfigParser()
print (configur.read('config.ini'))

timeStamps=[]
values=[]
InputDataList=[]
main_input_dict_1={}
main_input_dict_2={}
ssd_dict={}
OutputDataList=[]


    

def inputDataList():
    pattern="%m-%d-%Y %H:%m:%s"

    data=pd.read_csv(configur.get("SSD_code","MR_read_PHD_data_csvFile"))
    #mr_data=pd.read_csv("F:/CSVInput/PS_PHD/MR_output_tags.csv")
    
    
#     for total_tags in range(0,len(edge_asset_values)):
          
#         print(total_tags)
        
    for i,j in data.iterrows():            
        #print(i)
        TagName=i[0]
#         print(edge_asset_values[total_tags].split(".")[0])
#             if TagName== edge_asset_values[total_tags] or TagName == edge_asset_values[total_tags].split(".")[0]+".STDEV":
        if TagName== "TagName":
            pass
        else:
            
            print("Fetching data for ",TagName)

            if i[1] == "TimeStamp":
                pass
            else:
                dates=pd.to_datetime(i[1])
    #             print((dates - pd.Timestamp("1970-01-01")) / pd.Timedelta('1s'))
                epoch=(dates - pd.Timestamp("1970-01-01")) / pd.Timedelta('1s')
                final_timestamp=str(epoch)
                timeStamps.append(str(epoch))
    #             print(i[2])
                final_value=float(i[2])
                values.append(i[2])

            
            if i[0].split(".")[1] == "PV_RW":            
                main_input_dict_1={
                    "tagName": TagName,
                    "dataScienceTagName": "null",
                    "timeStampsToValueMap":{final_timestamp:final_value},
                    "tagConfiguration": {}
                    }
                
                InputDataList.append(main_input_dict_1)              
               
            elif i[0].split(".")[1] == "STDEV" :                    
                main_input_dict_2={
                    "tagName": TagName,
                    "dataScienceTagName": "null",
                    "timeStampsToValueMap":{final_timestamp:final_value},
                    "tagConfiguration": {}
                    }
                
                InputDataList.append(main_input_dict_2)
                
    with open(configur.get("Read_MR_Tags","MR_Output_Tags"), "r") as outfile:
        csv_reader = reader(outfile)
        header= next(csv_reader)
        if header != None:
            for row in csv_reader:
                main_output_dict_1={"tagName": row[0],"dataScienceTagName": "null","outputConfiguration": "null"}
                OutputDataList.append(main_output_dict_1)
    #print(OutputDataList)
    return InputDataList,OutputDataList

def final_json_file(main_config,InputDataList,OutputDataList):
    Final_dict={
        "JobId": "d29ddf43-7df4-490b-96fc-99f41eacbb1c",
        "ModelId": "model-cps-hbwnarea01nap01-pareto1",
        "CalculationType": "GED_DR_MASS_TEST",
        "Configuration":main_config,
        "InputDataList":InputDataList,
        "OutputDataList": OutputDataList
    }
    return Final_dict




def main_MR_func(): 
    print("-------------------------------------------------------------")
    print("MR CODE EXECUTION STARTED")
    print("-------------------------------------------------------------")	
    edge_asset_keys,edge_asset_values_1,edge_name_keys,edge_name_values,output_tags,GE_output_tags=read_MR_Tags()    
    series_1=pd.Series(edge_name_keys)
    series_2=pd.Series(edge_name_values)
    series_3=pd.Series(edge_asset_keys)
    series_4=pd.Series(edge_asset_values_1)
    
    Data1={"edge_names":series_1,"edge_name_values":series_2,"edge_asset":series_3,"edge_asset_values":series_4}
    dframe1= pd.DataFrame(Data1)

    
    dict_1=pd.Series(dframe1.edge_name_values.values,index= dframe1.edge_names).to_dict()
    dict_2=pd.Series(dframe1.edge_asset_values.values,index=dframe1.edge_asset).to_dict()
    res_dict={**dict_1,**dict_2}
    res_dict["CONFIG_FILE"]="TestConfiguration"
    res_dict["REACTION_INDICATOR"]="0"
    res_dict["TERMINAL_INDICATOR"]="1"
    res_dict["INTERVAL"]="30"
    res_dict["TOTAL_COMPONENTS"]="0"
    res_dict["MODEL_SERVICE_TOKEN"]="<Token>"
    res_dict["UNIT_STEADY_STATE_TAG"]="U0300_01.SSD1_ST"
    res_dict["UNIT_STEADY_STATE_REQUIREMENT"]="0.5"
    res_dict["INTERUNIT_INDICATOR"]="0"
    res_dict["MODEL_SERVICE_ENDPOINT"]="<URL>"
    res_dict["SAMPLE_DATA_FREQUENCY"]="100"
    res_dict["COMPONENT_INDICATOR"]="0"
    res_dict["DELAY"]="150"

    

    InputDataList,OutputDataList=inputDataList()

    Final_dict=final_json_file(res_dict,InputDataList,OutputDataList)

    import json

    json_object=json.dumps(Final_dict,indent=4)

    with open(configur.get("SSD_code","MR_input_JSON_file"),"w") as outfile:
        outfile.write(json_object)

    run_DR_GED(configur.get("SSD_code","MR_input_JSON_file"))

    pros= subprocess.Popen(["C:\\Windows\\syswow64\\WindowsPowerShell\\v1.0\\powershell.exe","-ExecutionPolicy","Unrestricted",".\\MR_Output_phd_data_Write.PS1"],stdout=sys.stdout)
    pros.communicate()
    
