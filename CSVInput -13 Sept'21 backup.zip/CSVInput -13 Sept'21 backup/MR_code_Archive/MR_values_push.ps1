﻿cd "F:\CSVInput\MR_code"
# Description: Powershell script to get PHD Tag data from multiple PHD Servers
# Author: Manasi Angane
# Date: 10th Dec 2019 (Tue)
# Variable Initializations
$inpTags = "F:\CSVInput\MR_csv_output.csv"
#$outRes = "F:\CSVInput\suncorDATA.csv"
#remove-item $outRes
$stTime="NOW"
$endTime="NOW"
add-type -path 'C:\Program Files (x86)\Common Files\Honeywell\Uniformance\phdapinet.dll'
$phdlib="uniformance.phd"
$phd=new-object -typename "$phdlib.phdhistorian"
#$data = import-csv $inpTags -Header 'tagname', 
$data = import-csv $inpTags 
$count = 1
write-host "for b4r"

  $phd_host = "localhost"
  $phd.DefaultServer=new-object -typename "$phdlib.PHDServer" $phd_host,API200
  $phd.DefaultServer.port=3100
  $phd.sampletype="RAW"
  $phd.reductiontype="None"
  
foreach($i in $data){ 
  #$phd_host = $i.phd_host

  $phdtag = $i.tagname
  write-host $i.tagname
  $phdtimestamp =$i.timestamp
  $phdvalue=$i.value

  $phd.starttime=$stTime
  $phd.endtime=$endTime
  #$tags=New-Object -typename "$phdlib.Tags"
  #tags.add($phdtag)
  #$value=New-Object -typename "$phdlib.Object"
  #$timestamp=New-Object -typename "$phdlib.String"
  #$timestamp.add($phdtimestamp)
  #$value.add($phdvalue)
 
  #$tags.add($phdtimestamp)
  #$value.add($phdvalue)
  #$timestamp.add($phdtimestamp)
  #$result=$phd.PutData($tags,$value,$timestamp)
  $result=$phd.PutData($i.tagname,$i.value,$i.timestamp)
  write-host $i.timeStamp
  #$stTime=$result.timeStamp.AddMinutes(-2000)
  #$endTime="NOW" 
}

